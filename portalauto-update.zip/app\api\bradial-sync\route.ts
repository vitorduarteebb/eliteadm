import { NextRequest, NextResponse } from 'next/server';
import { bradialService } from '@/lib/bradialService';

export async function GET() {
  try {
    console.log('🔄 GET /api/bradial-sync - Iniciando sincronização...');
    
    // Sincronizar leads do Bradial com o Kanban
    const leads = await bradialService.syncLeadsWithKanban();
    
    console.log(`✅ Sincronização GET concluída: ${leads.length} leads processados`);
    
    return NextResponse.json({
      success: true,
      message: 'Leads sincronizados com sucesso',
      leads: leads,
      count: leads.length,
      timestamp: new Date().toISOString(),
      debug: {
        apiEndpoint: '/api/bradial-sync',
        method: 'GET',
        leadsProcessed: leads.length,
        sampleLead: leads.length > 0 ? leads[0] : null
      }
    });
  } catch (error) {
    console.error('❌ Erro na sincronização GET:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Erro ao sincronizar leads',
      message: error instanceof Error ? error.message : 'Erro desconhecido',
      debug: {
        apiEndpoint: '/api/bradial-sync',
        method: 'GET',
        errorType: error instanceof Error ? error.constructor.name : 'Unknown',
        timestamp: new Date().toISOString()
      }
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    console.log('🔄 POST /api/bradial-sync - Processando requisição...');
    
    const { action, data } = await request.json();
    console.log(`📝 Ação solicitada: ${action}`, data);
    
    switch (action) {
      case 'sync':
        // Sincronização manual
        console.log('🔄 Executando sincronização manual...');
        const leads = await bradialService.syncLeadsWithKanban();
        
        console.log(`✅ Sincronização manual concluída: ${leads.length} leads`);
        
        return NextResponse.json({
          success: true,
          message: 'Sincronização manual realizada',
          leads: leads,
          count: leads.length,
          debug: {
            action: 'sync',
            leadsProcessed: leads.length,
            sampleLead: leads.length > 0 ? leads[0] : null,
            timestamp: new Date().toISOString()
          }
        });
        
      case 'webhook':
        // Processar webhook do Bradial
        console.log('📡 Processando webhook do Bradial...');
        await bradialService.handleWebhook(data);
        
        return NextResponse.json({
          success: true,
          message: 'Webhook processado com sucesso',
          debug: {
            action: 'webhook',
            event: data?.event || 'unknown',
            timestamp: new Date().toISOString()
          }
        });
        
      case 'update_lead':
        // Atualizar lead específico
        console.log('🔄 Atualizando lead específico...');
        const { leadId, updates } = data;
        let success = false;
        
        if (updates.status) {
          success = await bradialService.updateLeadStatus(leadId, updates.status);
          console.log(`📊 Status atualizado: ${updates.status} - Sucesso: ${success}`);
        }
        
        if (updates.assignee) {
          success = await bradialService.assignLead(leadId, updates.assignee);
          console.log(`👤 Responsável atualizado: ${updates.assignee} - Sucesso: ${success}`);
        }
        
        if (updates.note) {
          success = await bradialService.addNoteToLead(leadId, updates.note);
          console.log(`📝 Nota adicionada - Sucesso: ${success}`);
        }
        
        return NextResponse.json({
          success: success,
          message: success ? 'Lead atualizado com sucesso' : 'Erro ao atualizar lead',
          debug: {
            action: 'update_lead',
            leadId: leadId,
            updates: updates,
            success: success,
            timestamp: new Date().toISOString()
          }
        });
        
      case 'add_tag':
        // Adicionar tag ao lead
        console.log('🏷️ Adicionando tag ao lead...');
        const { leadId: addTagLeadId, tagId } = data;
        const tagAdded = await bradialService.addTagToLead(addTagLeadId, tagId);
        
        console.log(`✅ Tag adicionada: ${tagId} - Sucesso: ${tagAdded}`);
        
        return NextResponse.json({
          success: tagAdded,
          message: tagAdded ? 'Tag adicionada com sucesso' : 'Erro ao adicionar tag',
          debug: {
            action: 'add_tag',
            leadId: addTagLeadId,
            tagId: tagId,
            success: tagAdded,
            timestamp: new Date().toISOString()
          }
        });
        
      case 'remove_tag':
        // Remover tag do lead
        console.log('❌ Removendo tag do lead...');
        const { leadId: removeTagLeadId, tagId: removeTagId } = data;
        const tagRemoved = await bradialService.removeTagFromLead(removeTagLeadId, removeTagId);
        
        console.log(`✅ Tag removida: ${removeTagId} - Sucesso: ${tagRemoved}`);
        
        return NextResponse.json({
          success: tagRemoved,
          message: tagRemoved ? 'Tag removida com sucesso' : 'Erro ao remover tag',
          debug: {
            action: 'remove_tag',
            leadId: removeTagLeadId,
            tagId: removeTagId,
            success: tagRemoved,
            timestamp: new Date().toISOString()
          }
        });
        
      case 'test':
        // Teste da API
        console.log('🧪 Executando teste da API...');
        const testLeads = await bradialService.getLeads();
        const testTags = await bradialService.getTags();
        
        return NextResponse.json({
          success: true,
          message: 'Teste da API executado com sucesso',
          debug: {
            action: 'test',
            leadsCount: testLeads.length,
            tagsCount: testTags.length,
            sampleLead: testLeads.length > 0 ? testLeads[0] : null,
            sampleTag: testTags.length > 0 ? testTags[0] : null,
            timestamp: new Date().toISOString()
          }
        });
        
      default:
        console.log(`❌ Ação não reconhecida: ${action}`);
        return NextResponse.json({
          success: false,
          error: 'Ação não reconhecida',
          message: 'Ação deve ser: sync, webhook, update_lead, add_tag, remove_tag ou test',
          debug: {
            action: action,
            validActions: ['sync', 'webhook', 'update_lead', 'add_tag', 'remove_tag', 'test'],
            timestamp: new Date().toISOString()
          }
        }, { status: 400 });
    }
  } catch (error) {
    console.error('❌ Erro na API POST Bradial:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Erro interno do servidor',
      message: error instanceof Error ? error.message : 'Erro desconhecido',
      debug: {
        apiEndpoint: '/api/bradial-sync',
        method: 'POST',
        errorType: error instanceof Error ? error.constructor.name : 'Unknown',
        timestamp: new Date().toISOString()
      }
    }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    console.log('🔄 PUT /api/bradial-sync - Atualizando lead...');
    
    const { leadId, updates } = await request.json();
    console.log(`📝 Atualizando lead: ${leadId}`, updates);
    
    if (!leadId) {
      console.log('❌ ID do lead não fornecido');
      return NextResponse.json({
        success: false,
        error: 'ID do lead é obrigatório',
        debug: {
          method: 'PUT',
          leadId: leadId,
          updates: updates,
          timestamp: new Date().toISOString()
        }
      }, { status: 400 });
    }
    
    let success = false;
    
    // Atualizar status
    if (updates.status) {
      success = await bradialService.updateLeadStatus(leadId, updates.status);
      console.log(`📊 Status atualizado: ${updates.status} - Sucesso: ${success}`);
    }
    
    // Atribuir lead
    if (updates.assignee) {
      success = await bradialService.assignLead(leadId, updates.assignee);
      console.log(`👤 Responsável atualizado: ${updates.assignee} - Sucesso: ${success}`);
    }
    
    // Adicionar nota
    if (updates.note) {
      success = await bradialService.addNoteToLead(leadId, updates.note);
      console.log(`📝 Nota adicionada - Sucesso: ${success}`);
    }
    
    console.log(`✅ Lead ${leadId} atualizado - Sucesso: ${success}`);
    
    return NextResponse.json({
      success: success,
      message: success ? 'Lead atualizado com sucesso' : 'Erro ao atualizar lead',
      debug: {
        method: 'PUT',
        leadId: leadId,
        updates: updates,
        success: success,
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('❌ Erro ao atualizar lead:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Erro ao atualizar lead',
      message: error instanceof Error ? error.message : 'Erro desconhecido',
      debug: {
        method: 'PUT',
        errorType: error instanceof Error ? error.constructor.name : 'Unknown',
        timestamp: new Date().toISOString()
      }
    }, { status: 500 });
  }
}
