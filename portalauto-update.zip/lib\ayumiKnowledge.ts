// Conhecimento específico da Ayumi sobre CNH e legislação de trânsito
export const AYUMI_KNOWLEDGE = {
  cnh: {
    tipos: {
      'A': 'Habilita para conduzir veículos de duas ou três rodas, com ou sem carro lateral',
      'B': 'Habilita para conduzir veículos de quatro rodas, cujo peso bruto total não exceda a 3.500 kg e cuja lotação não exceda a 8 lugares',
      'C': 'Habilita para conduzir veículos utilizados no transporte de carga, cujo peso bruto total exceda a 3.500 kg',
      'D': 'Habilita para conduzir veículos utilizados no transporte de passageiros, cuja lotação exceda a 8 lugares',
      'E': 'Habilita para conduzir combinação de veículos em que a unidade tratora se enquadre nas categorias B, C ou D'
    },
    requisitos: {
      idade: {
        'A': '18 anos',
        'B': '18 anos',
        'C': '21 anos',
        'D': '21 anos',
        'E': '21 anos'
      },
      escolaridade: {
        'A': 'Alfabetizado',
        'B': 'Alfabetizado',
        'C': 'Ensino Fundamental completo',
        'D': 'Ensino Fundamental completo',
        'E': 'Ensino Fundamental completo'
      }
    },
    documentacao: [
      'RG ou CNH (se já tiver)',
      'CPF',
      'Comprovante de residência',
      'Certificado de conclusão do ensino fundamental (para C, D e E)',
      'Laudo de exame médico',
      'Laudo de exame psicológico',
      'Certificado de conclusão do curso teórico',
      'Certificado de conclusão do curso prático'
    ]
  },
  
  exames: {
    teorico: {
      descricao: 'Prova com 30 questões sobre legislação de trânsito, direção defensiva, mecânica básica e primeiros socorros',
      aprovação: 'Mínimo de 21 acertos (70%)',
      duracao: '40 minutos',
      custo: 'Varia conforme o DETRAN de cada estado'
    },
    pratico: {
      descricao: 'Prova prática de direção em via pública com instrutor credenciado',
      duracao: 'Aproximadamente 20 minutos',
      requisitos: 'Aprovação no exame teórico e conclusão das aulas práticas',
      avaliacao: 'Observação de comportamento, respeito às leis de trânsito e habilidade técnica'
    }
  },
  
  infracoes: {
    gravissima: {
      exemplos: [
        'Dirigir sob influência de álcool ou drogas',
        'Dirigir sem CNH',
        'Dirigir veículo sem placa',
        'Ultrapassar em local proibido'
      ],
      penalidades: [
        'Multa de R$ 2.934,70',
        'Suspensão da CNH por 12 meses',
        'Recolhimento da CNH',
        '7 pontos na carteira'
      ]
    },
    grave: {
      exemplos: [
        'Exceder velocidade em até 20%',
        'Dirigir sem cinto de segurança',
        'Usar celular ao volante',
        'Não respeitar sinalização'
      ],
      penalidades: [
        'Multa de R$ 293,47',
        '5 pontos na carteira'
      ]
    },
    media: {
      exemplos: [
        'Dirigir sem documentos obrigatórios',
        'Não usar equipamentos obrigatórios',
        'Estacionar em local proibido'
      ],
      penalidades: [
        'Multa de R$ 130,16',
        '4 pontos na carteira'
      ]
    },
    leve: {
      exemplos: [
        'Dirigir sem atenção',
        'Não manter distância segura',
        'Usar buzina em local proibido'
      ],
      penalidades: [
        'Multa de R$ 88,38',
        '3 pontos na carteira'
      ]
    }
  },
  
  cassacao: {
    causas: [
      'Dirigir sob influência de álcool (concentração igual ou superior a 0,6 g/L)',
      'Dirigir sem CNH',
      'Dirigir veículo sem placa',
      'Ultrapassar em local proibido',
      'Acumular 20 pontos ou mais na carteira em 12 meses'
    ],
    procedimentos: [
      'A CNH é cassada pelo DETRAN',
      'É necessário aguardar 2 anos para nova habilitação',
      'Deve-se fazer todo o processo novamente (exames, aulas, etc.)',
      'Não é possível renovar CNH cassada'
    ],
    verificacao: [
      'Consultar o site do DETRAN do estado',
      'Usar o aplicativo CNH Digital',
      'Consultar em posto do DETRAN',
      'Verificar no site do Denatran'
    ]
  },
  
  renovacao: {
    quando: [
      'CNH vencida',
      'Mudança de categoria',
      'Adição de categoria',
      'CNH extraviada ou danificada'
    ],
    prazos: {
      'A e B': 'Renovação a cada 10 anos até 50 anos, depois a cada 5 anos',
      'C, D e E': 'Renovação a cada 5 anos'
    },
    documentacao: [
      'CNH atual',
      'RG ou CNH',
      'CPF',
      'Comprovante de residência',
      'Laudo médico',
      'Laudo psicológico (se necessário)',
      'Certificado de curso de reciclagem (se aplicável)'
    ]
  },
  
  direcaoDefensiva: {
    principios: [
      'Conhecimento: Conhecer as leis de trânsito e funcionamento do veículo',
      'Atenção: Manter atenção constante ao trânsito',
      'Previsão: Antecipar situações de risco',
      'Decisão: Tomar decisões rápidas e corretas',
      'Habilidade: Ter habilidade técnica para conduzir'
    ],
    tecnicas: [
      'Manter distância segura do veículo à frente',
      'Verificar retrovisores constantemente',
      'Sinalizar todas as manobras',
      'Respeitar limites de velocidade',
      'Não dirigir sob influência de álcool ou drogas',
      'Usar sempre cinto de segurança',
      'Manter o veículo em bom estado'
    ]
  },
  
  sinalizacao: {
    placas: {
      regulamentacao: 'Indicam obrigações, proibições ou restrições',
      exemplos: [
        'Pare (obrigatório parar)',
        'Dê a preferência (ceder passagem)',
        'Velocidade máxima permitida',
        'Proibido estacionar'
      ]
    },
    semaforos: {
      vermelho: 'Parar obrigatoriamente',
      amarelo: 'Parar se for seguro',
      verde: 'Pode prosseguir com atenção'
    },
    faixas: {
      branca: 'Separação de fluxos no mesmo sentido',
      amarela: 'Separação de fluxos em sentidos opostos',
      azul: 'Estacionamento para deficientes'
    }
  },
  
  autoEscolaOnishi: {
    servicos: [
      'Cursos para CNH categoria B (carro)',
      'Aulas teóricas e práticas',
      'Simuladores de direção',
      'Preparação para exames',
      'Renovação de CNH',
      'Adição de categoria',
      'Cursos de reciclagem'
    ],
    diferencial: [
      'Instrutores experientes e credenciados',
      'Veículos modernos e bem conservados',
      'Metodologia personalizada',
      'Horários flexíveis',
      'Preços competitivos',
      'Acompanhamento completo do processo'
    ],
    localizacao: 'Auto Escola Onishi - Especializada em formação de condutores responsáveis'
  }
};

// Funções auxiliares para a Ayumi
export function getCNHInfo(categoria: string): string {
  const info = AYUMI_KNOWLEDGE.cnh.tipos[categoria as keyof typeof AYUMI_KNOWLEDGE.cnh.tipos];
  if (info) {
    return `CNH categoria ${categoria.toUpperCase()}: ${info}`;
  }
  return 'Categoria de CNH não encontrada. As categorias disponíveis são: A, B, C, D e E.';
}

export function getInfracoesByGravidade(gravidade: string): string {
  const infracoes = AYUMI_KNOWLEDGE.infracoes[gravidade as keyof typeof AYUMI_KNOWLEDGE.infracoes];
  if (infracoes) {
    return `Infrações ${gravidade}:\n${infracoes.exemplos.join('\n')}\n\nPenalidades:\n${infracoes.penalidades.join('\n')}`;
  }
  return 'Gravidade de infração não encontrada. As gravidades são: gravíssima, grave, média e leve.';
}

export function getDocumentacaoCNH(categoria: string): string {
  const docs = AYUMI_KNOWLEDGE.cnh.documentacao;
  const requisitos = AYUMI_KNOWLEDGE.cnh.requisitos;
  
  let resposta = `Documentação necessária para CNH categoria ${categoria.toUpperCase()}:\n\n`;
  resposta += `📋 Documentos básicos:\n${docs.slice(0, 3).join('\n')}\n\n`;
  
  if (['C', 'D', 'E'].includes(categoria.toUpperCase())) {
    resposta += `📚 Documentos adicionais:\n${docs.slice(3).join('\n')}\n\n`;
  }
  
  resposta += `📊 Requisitos:\n`;
  resposta += `• Idade mínima: ${requisitos.idade[categoria.toUpperCase() as keyof typeof requisitos.idade]}\n`;
  resposta += `• Escolaridade: ${requisitos.escolaridade[categoria.toUpperCase() as keyof typeof requisitos.escolaridade]}`;
  
  return resposta;
}

export function getRenovacaoInfo(categoria: string): string {
  const prazos = AYUMI_KNOWLEDGE.renovacao.prazos;
  const prazo = prazos[categoria.toUpperCase() as keyof typeof prazos];
  
  let resposta = `Renovação de CNH categoria ${categoria.toUpperCase()}:\n\n`;
  resposta += `⏰ Prazo: ${prazo}\n\n`;
  resposta += `📋 Documentação necessária:\n${AYUMI_KNOWLEDGE.renovacao.documentacao.join('\n')}\n\n`;
  resposta += `🔄 Quando renovar:\n${AYUMI_KNOWLEDGE.renovacao.quando.join('\n')}`;
  
  return resposta;
}

export function getCassacaoInfo(): string {
  let resposta = `Cassação de CNH:\n\n`;
  resposta += `🚫 Principais causas:\n${AYUMI_KNOWLEDGE.cassacao.causas.join('\n')}\n\n`;
  resposta += `📋 Procedimentos após cassação:\n${AYUMI_KNOWLEDGE.cassacao.procedimentos.join('\n')}\n\n`;
  resposta += `🔍 Como verificar status:\n${AYUMI_KNOWLEDGE.cassacao.verificacao.join('\n')}`;
  
  return resposta;
}
