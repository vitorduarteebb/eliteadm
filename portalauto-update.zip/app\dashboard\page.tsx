'use client';

import { useRouter } from 'next/navigation';
import { 
  Users, 
  Shield, 
  Bot, 
  BarChart3, 
  Settings, 
  Calendar,
  TrendingUp,
  FileText,
  Zap,
  UserCheck,
  Cog,
  ArrowRight,
  Brain,
  MessageSquare,
  LayoutGrid
} from 'lucide-react';
import { useEffect } from 'react';

export default function DashboardPage() {
  const router = useRouter();

  const navigationItems = [
    {
      name: 'Ayumi - IA EliteADM',
      description: 'Sua parceira de sucesso no sistema Elite',
      href: '/ayumi',
      icon: Bot,
      color: 'purple',
      bgColor: 'purple-100',
      iconColor: 'purple-600'
    },
    {
      name: 'Treinamento da Ayumi',
      description: 'Aperfeiçoe e corrija a IA com feedback dos usuários',
      href: '/dashboard/ayumi-training',
      icon: Brain,
      color: 'indigo',
      bgColor: 'indigo-100',
      iconColor: 'indigo-600'
    },
    {
      name: 'Quadro Kanban',
      description: 'Gerencie tarefas e projetos de forma visual',
      href: '/kanban',
      icon: LayoutGrid,
      color: 'emerald',
      bgColor: 'emerald-100',
      iconColor: 'emerald-600'
    },
    {
      name: 'Gerenciar Usuários',
      description: 'Controle completo de usuários e acessos',
      href: '/users',
      icon: Users,
      color: 'blue',
      bgColor: 'blue-100',
      iconColor: 'blue-600'
    },
    {
      name: 'Sistema de Permissões',
      description: 'Gestão de papéis e permissões',
      href: '/permissions',
      icon: Shield,
      color: 'green',
      bgColor: 'green-100',
      iconColor: 'green-600'
    },
    {
      name: 'Relatórios e Analytics',
      description: 'Métricas e insights do sistema',
      href: '/reports',
      icon: BarChart3,
      color: 'indigo',
      bgColor: 'indigo-100',
      iconColor: 'indigo-600'
    },
    {
      name: 'Configurações',
      description: 'Personalize o sistema EliteADM',
      href: '/settings',
      icon: Settings,
      color: 'gray',
      bgColor: 'gray-100',
      iconColor: 'gray-600'
    }
  ];

  // Debug: verificar se o módulo de treinamento está sendo renderizado
  useEffect(() => {
    console.log('🔍 Dashboard carregado');
    console.log('🔍 Módulo de treinamento:', navigationItems.find(item => item.name === 'Treinamento da Ayumi'));
    console.log('🔍 Total de itens:', navigationItems.length);
  }, []);

  const stats = [
    {
      title: 'Usuários Ativos',
      value: '25',
      change: '+12%',
      changeType: 'positive',
      icon: UserCheck,
      color: 'blue'
    },
    {
      title: 'Projetos Ativos',
      value: '12',
      change: '+5%',
      changeType: 'positive',
      icon: FileText,
      color: 'green'
    },
    {
      title: 'Uso de IA (Ayumi)',
      value: '0/100',
      change: 'Disponível',
      changeType: 'neutral',
      icon: Zap,
      color: 'purple'
    },
    {
      title: 'Sistema Online',
      value: '99.9%',
      change: 'Estável',
      changeType: 'positive',
      icon: Shield,
      color: 'blue'
    }
  ];

  const recentActivity = [
    { id: 1, action: 'Novo usuário registrado', user: 'João Silva', time: '2 minutos atrás', type: 'user' },
    { id: 2, action: 'Permissão atualizada', user: 'Admin Sistema', time: '15 minutos atrás', type: 'permission' },
    { id: 3, action: 'Relatório gerado', user: 'Maria Santos', time: '1 hora atrás', type: 'report' },
    { id: 4, action: 'Configuração alterada', user: 'Admin Sistema', time: '3 horas atrás', type: 'config' },
    { id: 5, action: 'Usuário removido', user: 'Admin Sistema', time: '5 horas atrás', type: 'user' },
    { id: 6, action: 'Feedback da Ayumi implementado', user: 'Admin Sistema', time: '4 horas atrás', type: 'ai' }
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'user': return <Users className="h-4 w-4 text-blue-500" />;
      case 'permission': return <Shield className="h-4 w-4 text-green-500" />;
      case 'report': return <BarChart3 className="h-4 w-4 text-indigo-500" />;
      case 'config': return <Settings className="h-4 w-4 text-gray-500" />;
      case 'ai': return <Brain className="h-4 w-4 text-indigo-500" />;
      default: return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">EliteADM</h1>
                <p className="text-sm text-gray-600">Sistema de Gerenciamento Elite</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                Modo de Teste
              </div>
              <div className="text-sm text-gray-500">
                Sistema funcionando sem autenticação para demonstração
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        {/* Welcome Section */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Bem-vindo ao EliteADM!</h2>
          <p className="text-lg text-gray-600 mb-4">
            Sistema completo de gerenciamento com IA integrada (Ayumi), controle de usuários e permissões avançadas.
          </p>
          <div className="bg-blue-100 text-blue-800 px-4 py-2 rounded-lg inline-block">
            <strong>Modo de Teste:</strong> Sistema funcionando sem autenticação para demonstração.
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <div key={index} className="bg-white rounded-lg shadow-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                    <p className={`text-sm ${
                      stat.changeType === 'positive' ? 'text-green-600' :
                      stat.changeType === 'negative' ? 'text-red-600' :
                      'text-gray-600'
                    }`}>
                      {stat.change}
                    </p>
                  </div>
                  <div className={`p-3 rounded-full bg-${stat.color}-100`}>
                    <IconComponent className={`h-6 w-6 text-${stat.color}-600`} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Navigation Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {navigationItems.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div key={index} className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow duration-200">
                <div className="flex items-center space-x-4 mb-4">
                  <div className={`p-3 rounded-full bg-${item.bgColor}`}>
                    <IconComponent className={`h-6 w-6 text-${item.iconColor}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900">{item.name}</h3>
                    <p className="text-sm text-gray-600">{item.description}</p>
                  </div>
                </div>
                <button
                  onClick={() => router.push(item.href)}
                  className="w-full bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center space-x-2"
                >
                  <span>Acessar</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Atividade Recente</h3>
          <div className="space-y-3">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                {getActivityIcon(activity.type)}
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                  <p className="text-xs text-gray-500">por {activity.user} • {activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Debug Info */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mt-8">
          <h3 className="text-lg font-semibold text-yellow-800 mb-2">Debug Info</h3>
          <p className="text-sm text-yellow-700">Módulo de treinamento definido: <strong>Sim</strong></p>
          <p className="text-sm text-yellow-700">Total de itens de navegação: <strong>{navigationItems.length}</strong></p>
          <p className="text-sm text-yellow-700">Módulo de treinamento encontrado: <strong>{navigationItems.find(item => item.name === 'Treinamento da Ayumi') ? 'Sim' : 'Não'}</strong></p>
        </div>
      </main>
    </div>
  );
}
