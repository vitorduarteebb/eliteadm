export interface BradialLead {
  id: string;
  name: string;
  phone: string;
  tags: string[];
  status: 'new' | 'contacted' | 'qualified' | 'convertido' | 'lost';
  lastMessage: string;
  lastActivity: string;
  assignedTo?: string;
  notes?: string;
}

export interface BradialTag {
  id: string;
  name: string;
  color: string;
  category: string;
}

export interface BradialMessage {
  id: string;
  leadId: string;
  content: string;
  direction: 'in' | 'out';
  timestamp: string;
  tags: string[];
}

class BradialService {
  private apiKey: string;
  private baseURL: string = 'https://api.bradial.com/v1'; // URL exemplo, ajustar conforme necessário

  constructor() {
    this.apiKey = process.env.BRADIAL_API_KEY || '8LjU6QckjMey6FDt7mDEj7VU';
  }

  private async makeRequest(endpoint: string, options: RequestInit = {}): Promise<any> {
    try {
      console.log(`🔄 Fazendo requisição para: ${this.baseURL}${endpoint}`);
      
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      });

      console.log(`📡 Resposta da API: ${response.status} ${response.statusText}`);

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`❌ Erro na API: ${response.status} - ${errorText}`);
        throw new Error(`Erro na API do Bradial: ${response.statusText}`);
      }

      const data = await response.json();
      console.log(`✅ Dados recebidos:`, data);
      return data;
    } catch (error) {
      console.error('❌ Erro ao chamar API do Bradial:', error);
      
      // Se a API não estiver disponível, usar dados de teste
      if (error instanceof Error && error.message.includes('fetch')) {
        console.log('🔄 API não disponível, usando dados de teste...');
        return this.getTestData();
      }
      
      throw new Error('Erro ao comunicar com o Bradial');
    }
  }

  // Dados de teste para desenvolvimento
  private getTestData(): any {
    console.log('🧪 Gerando dados de teste para Bradial...');
    
    return {
      leads: [
        {
          id: 'lead-001',
          name: 'João Silva',
          phone: '(11) 99999-9999',
          tags: ['novo', 'interessado', 'autoescola'],
          status: 'new',
          lastMessage: 'Olá! Gostaria de saber sobre o curso de direção',
          lastActivity: new Date().toISOString(),
          assignedTo: 'Instrutor Carlos',
          notes: 'Cliente interessado no curso completo'
        },
        {
          id: 'lead-002',
          name: 'Maria Santos',
          phone: '(11) 88888-8888',
          tags: ['contatado', 'respondido', 'em andamento'],
          status: 'contacted',
          lastMessage: 'Perfeito! Vou agendar a aula experimental',
          lastActivity: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          assignedTo: 'Instrutor Ana',
          notes: 'Aula experimental agendada para próxima semana'
        },
        {
          id: 'lead-003',
          name: 'Pedro Costa',
          phone: '(11) 77777-7777',
          tags: ['qualificado', 'proposta', 'alta prioridade'],
          status: 'qualified',
          lastMessage: 'Qual o valor do pacote completo?',
          lastActivity: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          assignedTo: 'Vendedor Roberto',
          notes: 'Cliente qualificado, enviar proposta comercial'
        },
        {
          id: 'lead-004',
          name: 'Ana Oliveira',
          phone: '(11) 66666-6666',
          tags: ['convertido', 'matriculado', 'curso iniciado'],
          status: 'convertido',
          lastMessage: 'Matrícula realizada com sucesso!',
          lastActivity: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          assignedTo: 'Secretária Juliana',
          notes: 'Matrícula confirmada, curso iniciado'
        }
      ],
      tags: [
        { id: 'tag-1', name: 'novo', color: '#3B82F6', category: 'status' },
        { id: 'tag-2', name: 'interessado', color: '#10B981', category: 'status' },
        { id: 'tag-3', name: 'contatado', color: '#F59E0B', category: 'status' },
        { id: 'tag-4', name: 'qualificado', color: '#8B5CF6', category: 'status' },
        { id: 'tag-5', name: 'convertido', color: '#059669', category: 'status' },
        { id: 'tag-6', name: 'urgente', color: '#DC2626', category: 'priority' },
        { id: 'tag-7', name: 'alta prioridade', color: '#EA580C', category: 'priority' }
      ]
    };
  }

  async getLeads(): Promise<BradialLead[]> {
    try {
      console.log('🔍 Buscando leads do Bradial...');
      const data = await this.makeRequest('/leads');
      
      if (!data.leads || data.leads.length === 0) {
        console.log('⚠️ Nenhum lead encontrado, usando dados de teste...');
        const testData = this.getTestData();
        return testData.leads || [];
      }
      
      console.log(`✅ ${data.leads.length} leads encontrados`);
      return data.leads || [];
    } catch (error) {
      console.error('❌ Erro ao buscar leads:', error);
      console.log('🔄 Usando dados de teste como fallback...');
      const testData = this.getTestData();
      return testData.leads || [];
    }
  }

  async getTags(): Promise<BradialTag[]> {
    try {
      console.log('🏷️ Buscando tags do Bradial...');
      const data = await this.makeRequest('/tags');
      
      if (!data.tags || data.tags.length === 0) {
        console.log('⚠️ Nenhuma tag encontrada, usando dados de teste...');
        const testData = this.getTestData();
        return testData.tags || [];
      }
      
      console.log(`✅ ${data.tags.length} tags encontradas`);
      return data.tags || [];
    } catch (error) {
      console.error('❌ Erro ao buscar tags:', error);
      console.log('🔄 Usando dados de teste como fallback...');
      const testData = this.getTestData();
      return testData.tags || [];
    }
  }

  async getLeadMessages(leadId: string): Promise<BradialMessage[]> {
    try {
      const data = await this.makeRequest(`/leads/${leadId}/messages`);
      return data.messages || [];
    } catch (error) {
      console.error('Erro ao buscar mensagens do lead:', error);
      return [];
    }
  }

  async updateLeadStatus(leadId: string, status: string): Promise<boolean> {
    try {
      await this.makeRequest(`/leads/${leadId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status }),
      });
      return true;
    } catch (error) {
      console.error('Erro ao atualizar status do lead:', error);
      return false;
    }
  }

  async addTagToLead(leadId: string, tagId: string): Promise<boolean> {
    try {
      await this.makeRequest(`/leads/${leadId}/tags`, {
        method: 'POST',
        body: JSON.stringify({ tagId }),
      });
      return true;
    } catch (error) {
      console.error('Erro ao adicionar tag ao lead:', error);
      return false;
    }
  }

  async removeTagFromLead(leadId: string, tagId: string): Promise<boolean> {
    try {
      await this.makeRequest(`/leads/${leadId}/tags/${tagId}`, {
        method: 'DELETE',
      });
      return true;
    } catch (error) {
      console.error('Erro ao remover tag do lead:', error);
      return false;
    }
  }

  async assignLead(leadId: string, userId: string): Promise<boolean> {
    try {
      await this.makeRequest(`/leads/${leadId}/assign`, {
        method: 'PUT',
        body: JSON.stringify({ userId }),
      });
      return true;
    } catch (error) {
      console.error('Erro ao atribuir lead:', error);
      return false;
    }
  }

  async addNoteToLead(leadId: string, note: string): Promise<boolean> {
    try {
      await this.makeRequest(`/leads/${leadId}/notes`, {
        method: 'POST',
        body: JSON.stringify({ note }),
      });
      return true;
    } catch (error) {
      console.error('Erro ao adicionar nota ao lead:', error);
      return false;
    }
  }

  // Mapeamento de tags do Bradial para colunas do Kanban
  getKanbanColumnFromTags(tags: string[]): string {
    const tagNames = tags.map(tag => tag.toLowerCase());
    console.log(`🏷️ Mapeando tags: [${tags.join(', ')}] para coluna do Kanban`);
    
    // Mapeamento baseado em palavras-chave das tags
    if (tagNames.some(tag => tag.includes('novo') || tag.includes('lead') || tag.includes('contato'))) {
      console.log('📍 Coluna: A Fazer (novo/lead/contato)');
      return 'todo';
    }
    
    if (tagNames.some(tag => tag.includes('contatado') || tag.includes('respondido') || tag.includes('em andamento'))) {
      console.log('📍 Coluna: Em Andamento (contatado/respondido)');
      return 'in-progress';
    }
    
    if (tagNames.some(tag => tag.includes('qualificado') || tag.includes('interessado') || tag.includes('proposta'))) {
      console.log('📍 Coluna: Em Revisão (qualificado/interessado)');
      return 'review';
    }
    
    if (tagNames.some(tag => tag.includes('convertido') || tag.includes('fechado') || tag.includes('matriculado'))) {
      console.log('📍 Coluna: Concluído (convertido/matriculado)');
      return 'done';
    }
    
    // Mapeamento por categoria de tag
    if (tagNames.some(tag => tag.includes('urgente') || tag.includes('prioridade'))) {
      console.log('📍 Coluna: Em Andamento (urgente/prioridade)');
      return 'in-progress';
    }
    
    if (tagNames.some(tag => tag.includes('duvida') || tag.includes('consulta'))) {
      console.log('📍 Coluna: Em Revisão (duvida/consulta)');
      return 'review';
    }
    
    // Padrão: nova coluna
    console.log('📍 Coluna: A Fazer (padrão)');
    return 'todo';
  }

  // Mapeamento de prioridade baseado nas tags
  getPriorityFromTags(tags: string[]): 'low' | 'medium' | 'high' | 'urgent' {
    const tagNames = tags.map(tag => tag.toLowerCase());
    
    if (tagNames.some(tag => tag.includes('urgente') || tag.includes('crítico'))) {
      return 'urgent';
    }
    
    if (tagNames.some(tag => tag.includes('alta') || tag.includes('importante'))) {
      return 'high';
    }
    
    if (tagNames.some(tag => tag.includes('média') || tag.includes('normal'))) {
      return 'medium';
    }
    
    return 'low';
  }

  // Converter lead do Bradial para tarefa do Kanban
  convertLeadToTask(lead: BradialLead): any {
    console.log(`🔄 Convertendo lead "${lead.name}" para tarefa do Kanban...`);
    
    const task = {
      id: `lead-${lead.id}`,
      title: `Lead: ${lead.name}`,
      description: `Telefone: ${lead.phone}\nÚltima mensagem: ${lead.lastMessage}\nTags: ${lead.tags.join(', ')}`,
      status: this.getKanbanColumnFromTags(lead.tags),
      priority: this.getPriorityFromTags(lead.tags),
      assignee: lead.assignedTo || 'Não atribuído',
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 7 dias
      tags: lead.tags,
      createdAt: lead.lastActivity,
      updatedAt: new Date().toISOString(),
      source: 'Bradial',
      leadId: lead.id,
      phone: lead.phone,
      notes: lead.notes || ''
    };
    
    console.log(`✅ Lead convertido:`, task);
    return task;
  }

  // Sincronizar leads com o Kanban
  async syncLeadsWithKanban(): Promise<any[]> {
    try {
      console.log('🔄 Iniciando sincronização Bradial → Kanban...');
      const leads = await this.getLeads();
      
      if (leads.length === 0) {
        console.log('⚠️ Nenhum lead encontrado para sincronizar');
        return [];
      }
      
      console.log(`📱 Processando ${leads.length} leads do WhatsApp...`);
      const tasks = leads.map(lead => this.convertLeadToTask(lead));
      
      console.log(`✅ Sincronização concluída: ${tasks.length} tarefas criadas no Kanban`);
      return tasks;
    } catch (error) {
      console.error('❌ Erro ao sincronizar leads:', error);
      return [];
    }
  }

  // Webhook para receber atualizações do Bradial
  async handleWebhook(payload: any): Promise<void> {
    try {
      const { event, data } = payload;
      console.log(`📡 Webhook recebido: ${event}`, data);
      
      switch (event) {
        case 'lead.created':
          console.log('🆕 Novo lead criado:', data);
          break;
          
        case 'lead.updated':
          console.log('🔄 Lead atualizado:', data);
          break;
          
        case 'message.received':
          console.log('💬 Nova mensagem recebida:', data);
          break;
          
        case 'tag.added':
          console.log('🏷️ Tag adicionada:', data);
          break;
          
        case 'tag.removed':
          console.log('❌ Tag removida:', data);
          break;
          
        default:
          console.log('❓ Evento não reconhecido:', event);
      }
    } catch (error) {
      console.error('❌ Erro ao processar webhook:', error);
    }
  }
}

export const bradialService = new BradialService();
