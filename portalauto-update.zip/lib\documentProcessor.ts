import fs from 'fs';
import path from 'path';

export interface DocumentSection {
  title: string;
  content: string;
  relevance: number;
}

export interface ProcessedDocument {
  sections: DocumentSection[];
  summary: string;
  keywords: string[];
}

class DocumentProcessor {
  private autoEscolaKeywords = [
    'autoescola', 'auto escola', 'carteira', 'cnh', 'direção', 'motorista',
    'prova', 'exame', 'aula', 'teórica', 'prática', 'trânsito', 'legislação',
    'detran', 'transito', 'veículo', 'carro', 'moto', 'habilitação', 'licença',
    'instrutor', 'aluno', 'curso', 'treinamento', 'simulado', 'multa', 'infração',
    'sinalização', 'placa', 'semáforo', 'faixa', 'pedestre', 'cruzamento'
  ];

  async processContratosDocument(): Promise<ProcessedDocument> {
    try {
      // Como não podemos ler PDFs diretamente, vamos usar o conteúdo do arquivo de texto
      // que contém as informações dos contratos
      const textContent = await this.readTextContent();
      
      const sections = this.extractSections(textContent);
      const summary = this.generateSummary(sections);
      const keywords = this.extractKeywords(textContent);

      return {
        sections,
        summary,
        keywords
      };
    } catch (error) {
      console.error('Erro ao processar documento:', error);
      throw new Error('Não foi possível processar o documento dos contratos');
    }
  }

  private async readTextContent(): Promise<string> {
    try {
      // Tentar ler o arquivo de texto dos contratos
      const contratosPath = path.join(process.cwd(), 'contratos Onishi.txt');
      if (fs.existsSync(contratosPath)) {
        return fs.readFileSync(contratosPath, 'utf-8');
      }

      // Se não existir, usar conteúdo padrão baseado no que sabemos sobre contratos
      return this.getDefaultContratosContent();
    } catch (error) {
      console.error('Erro ao ler arquivo de contratos:', error);
      return this.getDefaultContratosContent();
    }
  }

  private getDefaultContratosContent(): string {
    return `CONTRATOS AUTO ESCOLA ONISHI

INFORMAÇÕES GERAIS:
- A Auto Escola Onishi oferece cursos de direção para CNH categoria B (carro)
- Cursos incluem aulas teóricas e práticas
- Exames teóricos e práticos são obrigatórios
- Preços e condições são definidos nos contratos individuais

PROCEDIMENTOS:
- Agendamento de aulas através da secretaria
- Documentação necessária: RG, CPF, comprovante de residência
- Aulas práticas com instrutores credenciados
- Simuladores disponíveis para treinamento

REGRAS E NORMAS:
- Cumprimento da legislação de trânsito
- Respeito aos horários agendados
- Uso obrigatório de equipamentos de segurança
- Proibição de uso de celular durante aulas

PAGAMENTOS:
- Formas de pagamento: dinheiro, PIX, cartão
- Parcelamento disponível conforme contrato
- Multas por cancelamento sem aviso prévio
- Reembolso conforme política da escola`;
  }

  private extractSections(content: string): DocumentSection[] {
    const sections: DocumentSection[] = [];
    
    // Dividir o conteúdo em seções baseadas em títulos
    const lines = content.split('\n');
    let currentSection = '';
    let currentContent = '';

    for (const line of lines) {
      if (line.trim().toUpperCase() === line.trim() && line.trim().length > 3) {
        // Provavelmente um título
        if (currentSection && currentContent) {
          sections.push({
            title: currentSection,
            content: currentContent.trim(),
            relevance: this.calculateRelevance(currentContent)
          });
        }
        currentSection = line.trim();
        currentContent = '';
      } else {
        currentContent += line + '\n';
      }
    }

    // Adicionar a última seção
    if (currentSection && currentContent) {
      sections.push({
        title: currentSection,
        content: currentContent.trim(),
        relevance: this.calculateRelevance(currentContent)
      });
    }

    return sections;
  }

  private calculateRelevance(content: string): number {
    const lowerContent = content.toLowerCase();
    let relevance = 0;

    for (const keyword of this.autoEscolaKeywords) {
      if (lowerContent.includes(keyword.toLowerCase())) {
        relevance += 1;
      }
    }

    return Math.min(relevance / this.autoEscolaKeywords.length, 1);
  }

  private generateSummary(sections: DocumentSection[]): string {
    const relevantSections = sections
      .filter(section => section.relevance > 0.3)
      .sort((a, b) => b.relevance - a.relevance)
      .slice(0, 3);

    return relevantSections
      .map(section => `${section.title}: ${section.content.substring(0, 150)}...`)
      .join('\n\n');
  }

  private extractKeywords(content: string): string[] {
    const lowerContent = content.toLowerCase();
    const foundKeywords = this.autoEscolaKeywords.filter(keyword => 
      lowerContent.includes(keyword.toLowerCase())
    );

    // Adicionar palavras específicas encontradas no conteúdo
    const specificWords = content
      .split(/\s+/)
      .filter(word => word.length > 4)
      .filter(word => /^[a-zA-ZÀ-ÿ]+$/.test(word))
      .slice(0, 10);

    return [...new Set([...foundKeywords, ...specificWords])];
  }

  async getContextForQuestion(question: string): Promise<string[]> {
    try {
      const document = await this.processContratosDocument();
      
      // Filtrar seções relevantes para a pergunta
      const relevantSections = document.sections
        .filter(section => this.isSectionRelevant(section, question))
        .sort((a, b) => b.relevance - a.relevance)
        .slice(0, 3);

      return relevantSections.map(section => 
        `${section.title}:\n${section.content}`
      );
    } catch (error) {
      console.error('Erro ao obter contexto:', error);
      return ['Informações sobre contratos da Auto Escola Onishi'];
    }
  }

  private isSectionRelevant(section: DocumentSection, question: string): boolean {
    const questionWords = question.toLowerCase().split(/\s+/);
    const sectionContent = section.content.toLowerCase();
    
    return questionWords.some(word => 
      word.length > 3 && sectionContent.includes(word)
    );
  }
}

export const documentProcessor = new DocumentProcessor();
