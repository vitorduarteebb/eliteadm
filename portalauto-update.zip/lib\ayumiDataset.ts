import fs from 'fs';
import path from 'path';

import type { AyumiQA } from './ayumiDatabase';

function extractKeywordsFromQuestion(question: string): string[] {
	const normalized = question
		.toLowerCase()
		.replace(/[.,;:!?()\[\]{}"'`´^~–—_+=/\\|<>@#%&*0-9]/g, ' ')
		.replace(/\s+/g, ' ')
		.trim();
	const tokens = Array.from(new Set(normalized.split(' ')));
	const stopwords = new Set([
		'de','da','do','das','dos','e','a','o','as','os','um','uma','uns','umas','que','com','para','por','na','no','nas','nos','em','ao','à','às','aos','se','é','ser','tem','ter','qual','quais','como','ou','sobre','cliente','ayumi'
	]);
	const filtered = tokens.filter(t => t.length >= 3 && !stopwords.has(t));
	return filtered.slice(0, 8);
}

export function loadAyumiDataset(relativeFilePath: string): AyumiQA[] {
	try {
		const absPath = path.isAbsolute(relativeFilePath)
			? relativeFilePath
			: path.join(process.cwd(), relativeFilePath);
		if (!fs.existsSync(absPath)) return [];
		const content = fs.readFileSync(absPath, 'utf8');
		const entries: AyumiQA[] = [];
		// Captura blocos Pergunta: ... Resposta: ... até separador --- ou fim
		const regex = /Pergunta:\s*([\s\S]*?)\r?\n\s*Resposta:\s*([\s\S]*?)(?:\r?\n-{3,}\r?\n|\n{2,}(?=Pergunta:)|$)/g;
		let match: RegExpExecArray | null;
		while ((match = regex.exec(content)) !== null) {
			const questionRaw = match[1].trim();
			const answerRaw = match[2].trim();
			if (!questionRaw || !answerRaw) continue;
			const keywords = extractKeywordsFromQuestion(questionRaw);
			entries.push({
				keywords,
				question: questionRaw,
				answer: answerRaw,
				category: 'Base TXT'
			});
		}
		return entries;
	} catch (err) {
		console.error('Falha ao carregar dataset da Ayumi:', err);
		return [];
	}
}


