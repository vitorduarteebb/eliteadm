'use client';

import React from 'react';
import { User, Calendar, MessageSquare, Phone } from 'lucide-react';
import type { KanbanTask } from './KanbanBoard';

interface TaskCardProps {
  task: KanbanTask;
  priorityColors: Record<string, string>;
  priorityIcons: Record<string, React.ReactNode>;
  isDragging?: boolean;
}

export function TaskCard({ task, priorityColors, priorityIcons, isDragging = false }: TaskCardProps) {
  const isBradialLead = task.source === 'Bradial';

  return (
    <div
      className={`p-4 bg-white rounded-lg shadow-lg border border-gray-200 ${
        isDragging ? 'rotate-2' : ''
      } ${isBradialLead ? 'border-l-4 border-l-purple-500' : ''}`}
    >
      <div className="flex items-start justify-between mb-3">
        <h4 className="font-medium text-gray-900 text-sm leading-tight">
          {task.title}
        </h4>
        {isBradialLead && (
          <div className="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded-full flex items-center gap-1">
            <MessageSquare className="h-3 w-3" />
            WhatsApp
          </div>
        )}
      </div>

      <p className="text-gray-600 text-xs mb-3 line-clamp-2">
        {task.description}
      </p>

      {/* Informações específicas do Bradial */}
      {isBradialLead && task.phone && (
        <div className="flex items-center gap-2 mb-3 text-xs text-gray-500">
          <Phone className="h-3 w-3" />
          <span>{task.phone}</span>
        </div>
      )}

      <div className="flex items-center gap-2 mb-3">
        <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${priorityColors[task.priority]}`}>
          {priorityIcons[task.priority]}
          {task.priority === 'low' && 'Baixa'}
          {task.priority === 'medium' && 'Média'}
          {task.priority === 'high' && 'Alta'}
          {task.priority === 'urgent' && 'Urgente'}
        </span>
      </div>

      <div className="flex items-center justify-between text-xs text-gray-500">
        <div className="flex items-center gap-1">
          <User className="h-3 w-3" />
          <span>{task.assignee}</span>
        </div>
        <div className="flex items-center gap-1">
          <Calendar className="h-3 w-3" />
          <span>{new Date(task.dueDate).toLocaleDateString('pt-BR')}</span>
        </div>
      </div>

      {task.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-3">
          {task.tags.map((tag, tagIndex) => (
            <span
              key={tagIndex}
              className={`px-2 py-1 text-xs rounded-full ${
                isBradialLead 
                  ? 'bg-purple-100 text-purple-700' 
                  : 'bg-gray-100 text-gray-600'
              }`}
            >
              {tag}
            </span>
          ))}
        </div>
      )}

      {/* Notas do lead */}
      {isBradialLead && task.notes && (
        <div className="mt-3 p-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-700">
          <div className="font-medium mb-1">Notas:</div>
          <div className="line-clamp-2">{task.notes}</div>
        </div>
      )}
    </div>
  );
}
