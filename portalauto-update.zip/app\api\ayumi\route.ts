import { NextRequest, NextResponse } from 'next/server';
import { gptService } from '@/lib/gptService';
import { documentProcessor } from '@/lib/documentProcessor';

export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: 'Mensagem é obrigatória e deve ser uma string' },
        { status: 400 }
      );
    }

    // Validar se a pergunta é sobre autoescola
    const isValidQuestion = await gptService.validateQuestion(message);
    
    if (!isValidQuestion) {
      return NextResponse.json({
        answer: "Desculpe, só posso responder perguntas sobre autoescola, cursos de direção, legislação de trânsito e procedimentos da Auto Escola Onishi. Por favor, faça uma pergunta relacionada a esses temas.",
        source: 'Validação GPT',
        isAutoEscolaQuestion: false
      });
    }

    // Obter contexto relevante dos documentos
    const contextDocuments = await documentProcessor.getContextForQuestion(message);

    // Obter resposta do GPT
    const gptResponse = await gptService.getAutoEscolaResponse(message, contextDocuments);

    return NextResponse.json({
      answer: gptResponse.content,
      source: 'GPT + Documentos Auto Escola Onishi',
      isAutoEscolaQuestion: true,
      usage: gptResponse.usage,
      contextUsed: contextDocuments.length > 0
    });

  } catch (error) {
    console.error('Erro na API da Ayumi:', error);
    
    return NextResponse.json({
      error: 'Erro interno do servidor',
      message: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'API da Ayumi - Auto Escola Onishi',
    status: 'online',
    features: [
      'Respostas baseadas em GPT',
      'Validação de perguntas sobre autoescola',
      'Contexto dos documentos da Auto Escola Onishi',
      'Respostas em português brasileiro'
    ]
  });
}
