'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, AlertCircle, CheckCircle } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  source?: string;
  isAutoEscolaQuestion?: boolean;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export function AyumiInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Olá! Sou a Ayumi, sua IA especializada em Auto Escola Onishi! 🚗✨\n\nPosso responder suas dúvidas sobre:\n• Cursos de direção e CNH\n• Legislação de trânsito\n• Procedimentos da autoescola\n• Documentação necessária\n• E muito mais!\n\nComo posso te ajudar hoje?',
      isUser: false,
      timestamp: new Date(),
      source: 'Ayumi GPT',
      isAutoEscolaQuestion: true
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText.trim(),
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ayumi', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: inputText.trim() }),
      });

      const data = await response.json();

      if (response.ok) {
        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: data.answer,
          isUser: false,
          timestamp: new Date(),
          source: data.source,
          isAutoEscolaQuestion: data.isAutoEscolaQuestion,
          usage: data.usage
        };

        setMessages(prev => [...prev, aiMessage]);
      } else {
        throw new Error(data.error || 'Erro na comunicação com a Ayumi');
      }
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: 'Desculpe, ocorreu um erro ao processar sua pergunta. Tente novamente.',
        isUser: false,
        timestamp: new Date(),
        source: 'Erro'
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const formatTimestamp = (timestamp: Date) => {
    return timestamp.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getSourceIcon = (source?: string) => {
    if (source?.includes('GPT')) return <Bot className="h-4 w-4 text-blue-500" />;
    if (source?.includes('Validação')) return <CheckCircle className="h-4 w-4 text-green-500" />;
    if (source?.includes('Erro')) return <AlertCircle className="h-4 w-4 text-red-500" />;
    return <Bot className="h-4 w-4 text-gray-500" />;
  };

  const getSourceColor = (source?: string) => {
    if (source?.includes('GPT')) return 'text-blue-600';
    if (source?.includes('Validação')) return 'text-green-600';
    if (source?.includes('Erro')) return 'text-red-600';
    return 'text-gray-600';
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
            <Bot className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Ayumi - IA da Auto Escola Onishi</h2>
            <p className="text-sm text-gray-600">Powered by GPT • Especializada em Autoescola</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.isUser
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-900 shadow-sm border border-gray-200'
              }`}
            >
              <div className="flex items-start gap-2">
                {!message.isUser && (
                  <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Bot className="h-3 w-3 text-white" />
                  </div>
                )}
                <div className="flex-1">
                  <p className="whitespace-pre-wrap text-sm leading-relaxed">
                    {message.text}
                  </p>
                  
                  {/* Message Footer */}
                  <div className={`flex items-center justify-between mt-2 text-xs ${
                    message.isUser ? 'text-blue-100' : 'text-gray-500'
                  }`}>
                    <span>{formatTimestamp(message.timestamp)}</span>
                    
                    {!message.isUser && (
                      <div className="flex items-center gap-2">
                        {message.source && (
                          <div className={`flex items-center gap-1 ${getSourceColor(message.source)}`}>
                            {getSourceIcon(message.source)}
                            <span className="font-medium">{message.source}</span>
                          </div>
                        )}
                        
                        {message.isAutoEscolaQuestion === false && (
                          <span className="text-orange-600 font-medium">⚠️ Fora do escopo</span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Usage Info */}
                  {!message.isUser && message.usage && (
                    <div className="mt-2 pt-2 border-t border-gray-200">
                      <div className="text-xs text-gray-500">
                        <span className="font-medium">Tokens:</span> {message.usage.total_tokens} 
                        (prompt: {message.usage.prompt_tokens}, resposta: {message.usage.completion_tokens})
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white rounded-lg p-3 shadow-sm border border-gray-200">
              <div className="flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
                <span className="text-sm text-gray-600">Ayumi está pensando...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <div className="bg-white border-t border-gray-200 p-4">
        <form onSubmit={handleSubmit} className="flex gap-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Digite sua pergunta sobre autoescola..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-12"
              disabled={isLoading}
            />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">
              <Bot className="h-5 w-5" />
            </div>
          </div>
          <button
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            <Send className="h-4 w-4" />
            Enviar
          </button>
        </form>
        
        {/* Help Text */}
        <div className="mt-3 text-xs text-gray-500 text-center">
          💡 Dica: Faça perguntas específicas sobre autoescola, CNH, legislação de trânsito ou procedimentos da Auto Escola Onishi
        </div>
      </div>
    </div>
  );
}
