import { KanbanBoard } from '@/components/KanbanBoard';

export default function KanbanPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <KanbanBoard />
    </div>
  );
}

export const metadata = {
  title: 'Kanban - Auto Escola Onishi',
  description: 'Quadro Kanban para gerenciamento de tarefas e projetos',
};
