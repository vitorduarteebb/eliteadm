'use client';

import { useState, useEffect } from 'react';
import { 
  Brain, 
  Upload, 
  Download, 
  Play, 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  TrendingUp,
  BarChart3,
  FileText,
  Zap,
  Settings,
  RefreshCw,
  Trash2,
  Plus,
  Save,
  X,
  Send
} from 'lucide-react';

import type { TrainingFeedback, KnowledgeBaseEntry, TrainingMetrics } from '@/lib/ayumiTrainingSystem';
import {
  ayumiTrainingSystem,
  addTrainingFeedback as addTrainingFeedbackAPI,
  trainAyumiWithDataset as trainAyumiWithDatasetAPI,
  getAyumiMetrics as getAyumiMetricsAPI,
  getAyumiFeedback as getAyumiFeedbackAPI,
  searchAyumiKnowledge as searchAyumiKnowledgeAPI
} from '@/lib/ayumiTrainingSystem';

// Sistema simples de treinamento
interface TrainingData {
  question: string;
  answer: string;
  category: string;
  confidence: number;
  lastUpdated: Date;
}

interface FeedbackData {
  id: string;
  question: string;
  originalAnswer: string;
  feedback: 'positive' | 'negative' | 'neutral';
  comment: string;
  correctedAnswer?: string;
  category: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  timestamp: Date;
  status: 'pending' | 'implemented' | 'rejected';
}

class SimpleTrainingSystem {
  private trainingData: TrainingData[] = [];
  private feedbackData: FeedbackData[] = [];

  constructor() {
    this.loadData();
  }

  private loadData() {
    try {
      if (typeof window !== 'undefined') {
        const savedTraining = localStorage.getItem('ayumi-simple-training');
        const savedFeedback = localStorage.getItem('ayumi-simple-feedback');
        
        if (savedTraining) {
          this.trainingData = JSON.parse(savedTraining).map((item: any) => ({
            ...item,
            lastUpdated: new Date(item.lastUpdated)
          }));
        }
        
        if (savedFeedback) {
          this.feedbackData = JSON.parse(savedFeedback).map((item: any) => ({
            ...item,
            timestamp: new Date(item.timestamp)
          }));
        }
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    }
  }

  private saveData() {
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem('ayumi-simple-training', JSON.stringify(this.trainingData));
        localStorage.setItem('ayumi-simple-feedback', JSON.stringify(this.feedbackData));
      }
    } catch (error) {
      console.error('Erro ao salvar dados:', error);
    }
  }

  addTrainingData(data: Omit<TrainingData, 'lastUpdated'>) {
    const newData: TrainingData = {
      ...data,
      lastUpdated: new Date()
    };
    this.trainingData.push(newData);
    this.saveData();
    return newData;
  }

  addFeedback(data: Omit<FeedbackData, 'id' | 'timestamp'>) {
    const newFeedback: FeedbackData = {
      ...data,
      id: `feedback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date()
    };
    this.feedbackData.push(newFeedback);
    this.saveData();
    return newFeedback;
  }

  getTrainingData(): TrainingData[] {
    return [...this.trainingData];
  }

  getFeedbackData(): FeedbackData[] {
    return [...this.feedbackData].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  getMetrics() {
    const totalTraining = this.trainingData.length;
    const totalFeedback = this.feedbackData.length;
    const positiveFeedback = this.feedbackData.filter(f => f.feedback === 'positive').length;
    const negativeFeedback = this.feedbackData.filter(f => f.feedback === 'negative').length;
    
    return {
      totalTraining,
      totalFeedback,
      positiveFeedback,
      negativeFeedback,
      satisfaction: totalFeedback > 0 ? (positiveFeedback / totalFeedback) * 100 : 0,
      accuracy: totalTraining > 0 ? 85 + (positiveFeedback * 0.5) : 85
    };
  }

  exportData() {
    return {
      training: this.trainingData,
      feedback: this.feedbackData,
      exportDate: new Date().toISOString()
    };
  }

  importData(jsonData: string): {success: boolean, message: string} {
    try {
      const data = JSON.parse(jsonData);
      
      if (data.training && Array.isArray(data.training)) {
        this.trainingData = data.training.map((item: any) => ({
          ...item,
          lastUpdated: new Date(item.lastUpdated)
        }));
      }
      
      if (data.feedback && Array.isArray(data.feedback)) {
        this.feedbackData = data.feedback.map((item: any) => ({
          ...item,
          timestamp: new Date(item.timestamp)
        }));
      }
      
      this.saveData();
      return { success: true, message: 'Dados importados com sucesso!' };
    } catch (error) {
      return { success: false, message: `Erro ao importar dados: ${error}` };
    }
  }
}

const trainingSystem = new SimpleTrainingSystem();

export function AyumiRealTraining() {
	const [activeTab, setActiveTab] = useState<'overview' | 'training' | 'feedback' | 'knowledge'>('overview');
	const [trainingData, setTrainingData] = useState<KnowledgeBaseEntry[]>([]);
	const [feedbackData, setFeedbackData] = useState<TrainingFeedback[]>([]);
	const [metrics, setMetrics] = useState<TrainingMetrics>(getAyumiMetricsAPI());
  const [showTrainingForm, setShowTrainingForm] = useState(false);
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isTraining, setIsTraining] = useState(false);
  const [trainingProgress, setTrainingProgress] = useState(0);
	const [trainingAlert, setTrainingAlert] = useState<{
		type: 'success' | 'error' | 'warning';
		message: string;
	} | null>(null);

	// Estados do Chat de Pré-visualização
	const [previewQuestion, setPreviewQuestion] = useState('');
	const [previewAnswer, setPreviewAnswer] = useState<string | null>(null);
	const [previewEntry, setPreviewEntry] = useState<KnowledgeBaseEntry | null>(null);
	const [isPreviewLoading, setIsPreviewLoading] = useState(false);
	const [responseTimeMs, setResponseTimeMs] = useState<number | null>(null);
	const [correctionText, setCorrectionText] = useState('');
	const [correctionComment, setCorrectionComment] = useState('');
	const [correctionCategory, setCorrectionCategory] = useState('Geral');
	const [correctionPriority, setCorrectionPriority] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');

  // Carregar dados
	useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 3000);
    return () => clearInterval(interval);
  }, []);

	// Ocultar automaticamente alertas após alguns segundos
	useEffect(() => {
		if (trainingAlert) {
			const t = setTimeout(() => setTrainingAlert(null), 5000);
			return () => clearTimeout(t);
		}
	}, [trainingAlert]);

  const loadData = () => {
    setTrainingData(ayumiTrainingSystem.getKnowledgeBase());
    setFeedbackData(getAyumiFeedbackAPI());
    setMetrics(getAyumiMetricsAPI());
  };

  // Treinar com dataset
  const handleDatasetTraining = async () => {
    if (!selectedFile) return;

    setIsTraining(true);
    setTrainingProgress(0);
		setTrainingAlert(null);

    try {
      const text = await selectedFile.text();
      const lines = text.split('\n').filter(line => line.trim());
      
			let processedCount = 0;
			const totalLines = lines.length;
			const leftover = totalLines % 3;
      const dataset: Array<{question: string; answer: string; category: string}> = [];
      for (let i = 0; i < lines.length; i += 3) {
        if (i + 2 < lines.length) {
          const question = lines[i].trim();
          const answer = lines[i + 1].trim();
          const category = lines[i + 2].trim() || 'Geral';
          if (question && answer) {
            dataset.push({ question, answer, category });
            processedCount++;
          }
        }
        setTrainingProgress((i / Math.max(lines.length, 1)) * 100);
      }
      const result = trainAyumiWithDatasetAPI(dataset);
			setTrainingProgress(100);

			console.log(`✅ Treinamento concluído: ${processedCount} itens processados`);
      if (processedCount === 0) {
				setTrainingAlert({ type: 'error', message: 'Nenhum item válido foi encontrado no arquivo. Verifique o formato: Pergunta, Resposta, Categoria (3 linhas por item).' });
			} else {
        const leftoverMsg = leftover > 0 ? ` Observação: ${leftover} linha(s) final(is) foram ignoradas por não completar um bloco de 3.` : '';
        setTrainingAlert({ type: 'success', message: `Treinamento concluído. Novas: ${result.trainedCount}, Atualizadas: ${result.updatedCount}, Total na base: ${result.totalEntries}.${leftoverMsg}` });
			}
      
      // Recarregar dados
      loadData();
      
      // Limpar arquivo
      setSelectedFile(null);
      setShowTrainingForm(false);
      
    } catch (error) {
			console.error('❌ Erro no treinamento:', error);
			setTrainingAlert({ type: 'error', message: 'Ocorreu um erro ao processar o arquivo. Tente novamente.' });
    } finally {
      setIsTraining(false);
      setTrainingProgress(0);
    }
  };

  // Adicionar feedback real
  const handleAddFeedback = (feedbackData: Omit<TrainingFeedback, 'id' | 'timestamp'>) => {
    addTrainingFeedbackAPI(feedbackData);
    loadData();
    setShowFeedbackForm(false);
    setTrainingAlert({ type: 'success', message: 'Feedback registrado com sucesso.' });
  };

  // Exportar dados
  const handleExportData = () => {
    const data = trainingSystem.exportData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ayumi-training-data-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Importar dados reais
  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const result = ayumiTrainingSystem.importTrainingData(content);
      if (result.success) {
        setTrainingAlert({ type: 'success', message: result.message });
        loadData();
      } else {
        setTrainingAlert({ type: 'error', message: result.message });
      }
    };
    reader.readAsText(file);
  };

	// Pré-visualização: gerar resposta da IA com base na base de conhecimento
	const handleGeneratePreview = () => {
		if (!previewQuestion.trim()) return;
		setIsPreviewLoading(true);
		setPreviewAnswer(null);
		setPreviewEntry(null);
		const start = (typeof performance !== 'undefined') ? performance.now() : Date.now();
		try {
			const results = searchAyumiKnowledgeAPI(previewQuestion);
			if (results.length > 0) {
				const entry = results[0];
				setPreviewEntry(entry);
				setPreviewAnswer(entry.answer);
				setCorrectionCategory(entry.category || 'Geral');
			} else {
				setPreviewAnswer('Ainda não tenho conhecimento suficiente para responder. Você pode informar a resposta correta abaixo para treinar a IA.');
				setCorrectionCategory('Geral');
			}
			const end = (typeof performance !== 'undefined') ? performance.now() : Date.now();
			setResponseTimeMs(Math.max(1, Math.round((end as number) - (start as number))));
		} finally {
			setIsPreviewLoading(false);
		}
	};

	const handleMarkCorrect = () => {
		if (!previewQuestion || !previewAnswer) return;
		addTrainingFeedbackAPI({
			question: previewQuestion,
			originalAnswer: previewAnswer,
			userFeedback: 'positive',
			feedbackText: 'Marcado como correto via pré-visualização de treino',
			category: previewEntry?.category || correctionCategory || 'Geral',
			status: 'reviewed',
			priority: 'low',
			confidence: previewEntry?.confidence ?? 0.8,
			userRating: 5,
			tags: previewEntry?.tags ?? [ (previewEntry?.category || correctionCategory || 'geral').toLowerCase() ],
			metadata: {
				userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
				sessionId: `sess_${Date.now()}`,
				responseTime: responseTimeMs || 0,
				context: 'preview-training'
			}
		});
		setTrainingAlert({ type: 'success', message: 'Resposta marcada como correta. Obrigado!' });
		loadData();
	};

	const handleSubmitCorrection = () => {
		if (!previewQuestion || !previewAnswer || !correctionText.trim()) {
			setTrainingAlert({ type: 'error', message: 'Informe a resposta correta para aplicar a correção.' });
			return;
		}
		addTrainingFeedbackAPI({
			question: previewQuestion,
			originalAnswer: previewAnswer,
			userFeedback: 'negative',
			feedbackText: correctionComment || 'Correção aplicada via pré-visualização de treino',
			correctedAnswer: correctionText,
			category: correctionCategory || previewEntry?.category || 'Geral',
			status: 'pending',
			priority: correctionPriority,
			confidence: previewEntry?.confidence ?? 0.6,
			userRating: 2,
			tags: previewEntry?.tags ?? [ (correctionCategory || 'geral').toLowerCase() ],
			metadata: {
				userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
				sessionId: `sess_${Date.now()}`,
				responseTime: responseTimeMs || 0,
				context: 'preview-training'
			}
		});
		setTrainingAlert({ type: 'success', message: 'Correção registrada e aplicada à base de conhecimento.' });
		setCorrectionText('');
		setCorrectionComment('');
		loadData();
	};

  const tabs = [
    { id: 'overview', name: 'Visão Geral', icon: BarChart3 },
    { id: 'training', name: 'Treinamento', icon: Brain },
    { id: 'feedback', name: 'Feedback', icon: FileText },
    { id: 'knowledge', name: 'Base de Conhecimento', icon: Zap }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'training':
        return <TrainingTab />;
      case 'feedback':
        return <FeedbackTab />;
      case 'knowledge':
        return <KnowledgeTab />;
      default:
        return <OverviewTab />;
    }
  };

  const OverviewTab = () => (
    <div className="space-y-6">
      {/* Métricas Principais */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Precisão</p>
              <p className="text-2xl font-bold text-green-600">{(metrics.accuracy * 100).toFixed(1)}%</p>
            </div>
            <div className="p-3 rounded-full bg-green-100">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Satisfação</p>
              <p className="text-2xl font-bold text-blue-600">{(metrics.userSatisfaction * 100).toFixed(1)}%</p>
            </div>
            <div className="p-3 rounded-full bg-blue-100">
              <CheckCircle className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Dados Treinados</p>
              <p className="text-2xl font-bold text-purple-600">{trainingData.length}</p>
            </div>
            <div className="p-3 rounded-full bg-purple-100">
              <Brain className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Feedback</p>
              <p className="text-2xl font-bold text-orange-600">{metrics.feedbackCount}</p>
            </div>
            <div className="p-3 rounded-full bg-orange-100">
              <FileText className="h-6 w-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Ações Rápidas */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Ações Rápidas</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => setShowTrainingForm(true)}
            className="p-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-105"
          >
            <div className="text-center">
              <Brain className="h-8 w-8 mx-auto mb-2" />
              <p className="font-medium">Treinar IA</p>
              <p className="text-sm opacity-90">Com dataset</p>
            </div>
          </button>
          
          <button
            onClick={handleExportData}
            className="p-4 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg hover:from-green-600 hover:to-green-700 transition-all duration-200 transform hover:scale-105"
          >
            <div className="text-center">
              <Download className="h-8 w-8 mx-auto mb-2" />
              <p className="font-medium">Exportar Dados</p>
              <p className="text-sm opacity-90">Backup completo</p>
            </div>
          </button>
          
          <button
            onClick={() => setShowFeedbackForm(true)}
            className="p-4 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg hover:from-purple-600 hover:to-purple-700 transition-all duration-200 transform hover:scale-105"
          >
            <div className="text-center">
              <Plus className="h-8 w-8 mx-auto mb-2" />
              <p className="font-medium">Novo Feedback</p>
              <p className="text-sm opacity-90">Manual</p>
            </div>
          </button>
        </div>
      </div>

      {/* Status */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-green-800 mb-4">✅ Sistema Funcionando</h3>
        <div className="space-y-2 text-sm text-green-700">
          <p>• <strong>Componente AyumiRealTraining</strong> carregado com sucesso</p>
          <p>• <strong>Sistema de treinamento</strong> ativo e operacional</p>
          <p>• <strong>Métricas em tempo real</strong> sendo exibidas</p>
          <p>• <strong>Interface responsiva</strong> funcionando perfeitamente</p>
          <p>• <strong>Armazenamento local</strong> funcionando</p>
        </div>
      </div>
    </div>
  );

	const TrainingTab = () => (
    <div className="space-y-6">
      {/* Chat de Pré-visualização para rotulagem */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Chat de Pré-visualização (Modo Treino)</h3>
        <div className="space-y-3">
          <div className="flex space-x-2">
            <input
              type="text"
              value={previewQuestion}
              onChange={(e) => setPreviewQuestion(e.target.value)}
              placeholder="Digite sua pergunta aqui..."
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
            <button
              onClick={handleGeneratePreview}
              disabled={!previewQuestion.trim() || isPreviewLoading}
              className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              {isPreviewLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Gerando...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Gerar Resposta
                </>
              )}
            </button>
          </div>

          {previewAnswer && (
            <div className="mt-4 space-y-3">
              <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <p className="text-sm text-gray-700 whitespace-pre-wrap">{previewAnswer}</p>
                <div className="mt-2 flex items-center justify-between text-xs text-gray-500">
                  <span>Categoria: <strong>{previewEntry?.category || correctionCategory}</strong></span>
                  <span>Confiança: <strong>{Math.round((previewEntry?.confidence ?? 0.75) * 100)}%</strong></span>
                  {responseTimeMs !== null && (
                    <span>Tempo de resposta: <strong>{responseTimeMs}ms</strong></span>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <button
                  onClick={handleMarkCorrect}
                  className="bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700"
                >
                  <CheckCircle className="h-4 w-4 mr-1 inline" /> Correta
                </button>
              </div>

              {/* Campos de correção */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Resposta Corrigida (se estiver errada)</label>
                  <textarea
                    value={correctionText}
                    onChange={(e) => setCorrectionText(e.target.value)}
                    rows={3}
                    placeholder="Digite a resposta correta aqui..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Comentário</label>
                  <input
                    type="text"
                    value={correctionComment}
                    onChange={(e) => setCorrectionComment(e.target.value)}
                    placeholder="Por que a resposta está errada?"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Categoria</label>
                  <input
                    type="text"
                    value={correctionCategory}
                    onChange={(e) => setCorrectionCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Prioridade</label>
                  <select
                    value={correctionPriority}
                    onChange={(e) => setCorrectionPriority(e.target.value as any)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="low">Baixa</option>
                    <option value="medium">Média</option>
                    <option value="high">Alta</option>
                    <option value="critical">Crítica</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end mt-2">
                <button
                  onClick={handleSubmitCorrection}
                  disabled={!correctionText.trim()}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 disabled:opacity-50"
                >
                  Aplicar Correção
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
			{/* Alertas de resultado do treinamento */}
			{trainingAlert && (
				<div className={`${
					trainingAlert.type === 'success' ? 'bg-green-50 border-green-200 text-green-800' :
					trainingAlert.type === 'warning' ? 'bg-yellow-50 border-yellow-200 text-yellow-800' :
					'bg-red-50 border-red-200 text-red-800'
				} border rounded-lg p-4 flex items-start justify-between`}>
					<div className="flex items-start">
						{trainingAlert.type === 'success' ? (
							<CheckCircle className="h-5 w-5 mr-2 mt-0.5" />
						) : (
							<AlertCircle className="h-5 w-5 mr-2 mt-0.5" />
						)}
						<span className="text-sm">{trainingAlert.message}</span>
					</div>
					<button
						onClick={() => setTrainingAlert(null)}
						className="text-current hover:opacity-70"
						title="Fechar"
					>
						<X className="h-4 w-4" />
					</button>
				</div>
			)}
      {/* Upload de Dataset */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Treinar IA com Dataset</h3>
        
          <div className="space-y-4">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-sm text-gray-600 mb-2">
              Arraste um arquivo de texto ou clique para selecionar
            </p>
            <p className="text-xs text-gray-500 mb-4">
              Formato: Pergunta (linha 1), Resposta (linha 2) e Categoria (linha 3)
            </p>
            <input
              type="file"
              accept=".txt,.csv"
              onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
              className="hidden"
              id="dataset-upload"
            />
            <label
              htmlFor="dataset-upload"
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 cursor-pointer"
            >
              Selecionar Arquivo
            </label>
          </div>

          {selectedFile && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                  <span className="text-sm text-green-800">
                    Arquivo selecionado: <strong>{selectedFile.name}</strong>
                  </span>
                </div>
                <button
                  onClick={() => setSelectedFile(null)}
                  className="text-green-600 hover:text-green-800"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}

          {isTraining && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-blue-800">Treinando IA...</span>
                <span className="text-sm text-blue-600">{trainingProgress.toFixed(0)}%</span>
              </div>
              <div className="w-full bg-blue-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${trainingProgress}%` }}
                ></div>
              </div>
            </div>
          )}

          <button
            onClick={handleDatasetTraining}
            disabled={!selectedFile || isTraining}
            className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isTraining ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Treinando...
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Iniciar Treinamento
              </>
            )}
          </button>
        </div>
      </div>

      {/* Ações de Manutenção */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Manutenção da IA</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={handleExportData}
            className="p-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
          >
            <Download className="h-4 w-4 mr-2" />
            Exportar Dados
          </button>
          
          <label className="p-4 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center cursor-pointer">
            <Upload className="h-4 w-4 mr-2" />
            Importar Dados
            <input
              type="file"
              accept=".json"
              onChange={handleImportData}
              className="hidden"
            />
          </label>
          
          <button
            onClick={() => {
              if (confirm('Tem certeza que deseja limpar todos os dados? Esta ação não pode ser desfeita.')) {
                localStorage.removeItem('ayumi-simple-training');
                localStorage.removeItem('ayumi-simple-feedback');
                loadData();
              }
            }}
            className="p-4 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center justify-center"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Limpar Dados
          </button>
        </div>
      </div>
    </div>
  );

  const FeedbackTab = () => (
    <div className="space-y-6">
      {/* Lista de Feedback */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Feedback de Treinamento</h3>
          <button
            onClick={() => setShowFeedbackForm(true)}
            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 flex items-center"
          >
            <Plus className="h-4 w-4 mr-2" />
            Novo Feedback
          </button>
        </div>

        <div className="space-y-4">
          {feedbackData.map((item) => (
            <div key={item.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">{item.question}</h4>
                  <p className="text-sm text-gray-600 mt-1">{item.feedbackText}</p>
                  <div className="flex items-center space-x-4 mt-2">
                    <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${
                      item.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      item.status === 'implemented' ? 'bg-green-100 text-green-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {item.status === 'pending' ? <Clock className="h-3 w-3 mr-1" /> :
                       item.status === 'implemented' ? <CheckCircle className="h-3 w-3 mr-1" /> :
                       <AlertCircle className="h-3 w-3 mr-1" />}
                      {item.status}
                    </span>
                    <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${
                      item.priority === 'critical' ? 'bg-red-100 text-red-800' :
                      item.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                      item.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {item.priority}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {feedbackData.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>Nenhum feedback encontrado</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const KnowledgeTab = () => (
    <div className="space-y-6">
      {/* Base de Conhecimento */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Base de Conhecimento</h3>
        
        <div className="space-y-4">
          {trainingData.map((entry, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">{entry.question}</h4>
                  <p className="text-sm text-gray-600 mt-1">{entry.answer}</p>
                  <div className="flex items-center space-x-4 mt-2">
                    <span className="text-xs text-gray-500">Categoria: {entry.category}</span>
                    <span className="text-xs text-gray-500">Precisão: {(entry.confidence * 100).toFixed(0)}%</span>
                    <span className="text-xs text-gray-500">Atualizado: {entry.lastUpdated.toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {trainingData.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Zap className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>Base de conhecimento vazia</p>
              <p className="text-sm mt-2">Use a aba "Treinamento" para adicionar dados</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full flex items-center justify-center mr-4">
              <Brain className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Sistema Real de Treinamento da Ayumi</h1>
              <p className="text-lg text-gray-600">Treine, melhore e gerencie sua IA com funcionalidades reais</p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-lg shadow-lg">
        <nav className="flex space-x-8 p-6 border-b border-gray-200">
          {tabs.map((tab) => {
            const IconComponent = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-purple-500 text-purple-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <IconComponent className="h-4 w-4" />
                  <span>{tab.name}</span>
                </div>
              </button>
            );
          })}
        </nav>

        {/* Tab Content */}
        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>

      {/* Modais */}
      {showTrainingForm && (
        <TrainingFormModal onClose={() => setShowTrainingForm(false)} />
      )}

      {showFeedbackForm && (
        <FeedbackFormModal onClose={() => setShowFeedbackForm(false)} onSubmit={handleAddFeedback} />
      )}
    </div>
  );
}

// Modal de Formulário de Treinamento
function TrainingFormModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Treinar IA com Dataset</h3>
        </div>
        
        <div className="p-6">
          <p className="text-gray-600 mb-4">
            Para treinar a IA, prepare um arquivo de texto com o seguinte formato:
          </p>
          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <pre className="text-sm text-gray-700">
{`Pergunta 1
Resposta 1
Categoria 1

Pergunta 2
Resposta 2
Categoria 2

...`}
            </pre>
          </div>
        </div>
        
        <div className="px-6 py-4 border-t border-gray-200 flex justify-end">
          <button
            onClick={onClose}
            className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}

// Modal de Formulário de Feedback
function FeedbackFormModal({ 
  onClose, 
  onSubmit 
}: { 
  onClose: () => void;
  onSubmit: (feedback: Omit<TrainingFeedback, 'id' | 'timestamp'>) => void;
}) {
  const [formData, setFormData] = useState({
    question: '',
    originalAnswer: '',
    userFeedback: 'neutral' as const,
    feedbackText: '',
    correctedAnswer: '',
    category: 'Geral',
    priority: 'medium' as const,
    confidence: 0.8,
    userRating: 3
  });

  const handleSubmit = () => {
    if (formData.question && formData.originalAnswer && formData.feedbackText) {
      onSubmit({
        question: formData.question,
        originalAnswer: formData.originalAnswer,
        userFeedback: formData.userFeedback,
        feedbackText: formData.feedbackText,
        correctedAnswer: formData.correctedAnswer,
        category: formData.category,
        priority: formData.priority,
        status: 'pending',
        confidence: formData.confidence,
        userRating: formData.userRating,
        tags: [formData.category.toLowerCase()],
        metadata: {
          userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
          sessionId: `sess_${Date.now()}`,
          responseTime: 0,
          context: 'manual-feedback'
        }
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Novo Feedback</h3>
        </div>
        
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Pergunta</label>
            <textarea
              value={formData.question}
              onChange={(e) => setFormData({...formData, question: e.target.value})}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Resposta Original da IA</label>
            <textarea
              value={formData.originalAnswer}
              onChange={(e) => setFormData({...formData, originalAnswer: e.target.value})}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Feedback</label>
              <select
                value={formData.userFeedback}
                onChange={(e) => setFormData({...formData, userFeedback: e.target.value as any})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="positive">Positivo</option>
                <option value="neutral">Neutro</option>
                <option value="negative">Negativo</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Prioridade</label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({...formData, priority: e.target.value as any})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="low">Baixa</option>
                <option value="medium">Média</option>
                <option value="high">Alta</option>
                <option value="critical">Crítica</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Comentário do Feedback</label>
            <textarea
              value={formData.feedbackText}
              onChange={(e) => setFormData({...formData, feedbackText: e.target.value})}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Resposta Corrigida (Opcional)</label>
            <textarea
              value={formData.correctedAnswer}
              onChange={(e) => setFormData({...formData, correctedAnswer: e.target.value})}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="Digite a resposta corrigida se souber..."
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Categoria</label>
            <input
              type="text"
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
        </div>
        
        <div className="px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
          <button
            onClick={onClose}
            className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400"
          >
            Cancelar
          </button>
          <button
            onClick={handleSubmit}
            disabled={!formData.question || !formData.originalAnswer || !formData.feedbackText}
            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Salvar Feedback
          </button>
        </div>
      </div>
    </div>
  );
}
