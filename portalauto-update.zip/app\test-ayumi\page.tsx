'use client';

import { useState } from 'react';
import { AyumiPerformanceAnalytics } from '@/components/AyumiPerformanceAnalytics';
import { AyumiFeedbackCorrections } from '@/components/AyumiFeedbackCorrections';

export default function TestAyumiPage() {
  const [activeComponent, setActiveComponent] = useState<'performance' | 'feedback'>('performance');

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">
          🧪 Teste dos Componentes da Ayumi
        </h1>
        
        {/* Controles */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Controles de Teste</h2>
          <div className="flex space-x-4">
            <button
              onClick={() => setActiveComponent('performance')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeComponent === 'performance'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              📊 Performance Analytics
            </button>
            <button
              onClick={() => setActiveComponent('feedback')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeComponent === 'feedback'
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              💬 Feedback Corrections
            </button>
          </div>
        </div>

        {/* Status */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Status dos Componentes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">AyumiPerformanceAnalytics</h3>
              <p className="text-sm text-gray-600">
                Status: <span className="text-green-600 font-medium">✅ Disponível</span>
              </p>
              <p className="text-sm text-gray-600">
                Tipo: {typeof AyumiPerformanceAnalytics}
              </p>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">AyumiFeedbackCorrections</h3>
              <p className="text-sm text-gray-600">
                Status: <span className="text-green-600 font-medium">✅ Disponível</span>
              </p>
              <p className="text-sm text-gray-600">
                Tipo: {typeof AyumiFeedbackCorrections}
              </p>
            </div>
          </div>
        </div>

        {/* Renderização dos Componentes */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Componente Ativo: {activeComponent === 'performance' ? 'Performance Analytics' : 'Feedback Corrections'}
          </h2>
          
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
            {activeComponent === 'performance' ? (
              <div>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <p className="text-sm text-blue-800">
                    <strong>Debug:</strong> Renderizando AyumiPerformanceAnalytics
                  </p>
                </div>
                <AyumiPerformanceAnalytics />
              </div>
            ) : (
              <div>
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-4">
                  <p className="text-sm text-purple-800">
                    <strong>Debug:</strong> Renderizando AyumiFeedbackCorrections
                  </p>
                </div>
                <AyumiFeedbackCorrections />
              </div>
            )}
          </div>
        </div>

        {/* Informações de Debug */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mt-8">
          <h2 className="text-xl font-semibold text-yellow-800 mb-4">🔍 Informações de Debug</h2>
          <div className="space-y-2 text-sm text-yellow-700">
            <p>• Componente ativo: <strong>{activeComponent}</strong></p>
            <p>• AyumiPerformanceAnalytics: <strong>{typeof AyumiPerformanceAnalytics}</strong></p>
            <p>• AyumiFeedbackCorrections: <strong>{typeof AyumiFeedbackCorrections}</strong></p>
            <p>• Página renderizada: <strong>Sim</strong></p>
            <p>• Status: <strong>Funcionando</strong></p>
          </div>
        </div>
      </div>
    </div>
  );
}
