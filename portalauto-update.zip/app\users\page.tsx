'use client';

import { useRouter } from 'next/navigation';
import { LogOut, Home, ArrowLeft, Users, Clock, Shield } from 'lucide-react';

export default function UsersPage() {
  const router = useRouter();

  const handleBackToMain = () => {
    router.push('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header com Navegação */}
      <div className="bg-white shadow-lg border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Lado Esquerdo - Título e Botão Voltar */}
            <div className="flex items-center space-x-4">
              <button
                onClick={handleBackToMain}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
                <span>Voltar ao Menu</span>
              </button>
              <div className="h-6 w-px bg-gray-300"></div>
              <h1 className="text-2xl font-bold text-gray-900">Gerenciamento de Usuários EliteADM</h1>
            </div>

            {/* Lado Direito - Info do Usuário e Logout */}
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-500">Modo de Teste</p>
                <p className="font-medium text-gray-900">Administrador</p>
                <p className="text-xs text-gray-500 capitalize">admin</p>
              </div>
              <button
                onClick={() => router.push('/dashboard')}
                className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
              >
                <Home className="h-4 w-4" />
                <span>Dashboard</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        {/* Quick Navigation */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white hover:from-blue-600 hover:to-blue-700 transition-all duration-200 cursor-pointer" onClick={() => router.push('/users/equipe')}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold">Gestão de Equipe</h3>
                <p className="text-blue-100 text-sm">Gerencie membros e performance</p>
              </div>
              <Users className="h-10 w-10 text-blue-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white hover:from-green-600 hover:to-green-700 transition-all duration-200 cursor-pointer" onClick={() => router.push('/users/cargas-horarias')}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold">Cargas Horárias</h3>
                <p className="text-green-100 text-sm">Controle de tempo e produtividade</p>
              </div>
              <Clock className="h-10 w-10 text-green-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white hover:from-purple-600 hover:to-purple-700 transition-all duration-200 cursor-pointer" onClick={() => router.push('/permissions')}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold">Permissões</h3>
                <p className="text-purple-100 text-sm">Configure papéis e acessos</p>
              </div>
              <Shield className="h-10 w-10 text-purple-200" />
            </div>
          </div>
        </div>

        {/* Status */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-green-800 mb-4">✅ Sistema Funcionando</h3>
          <div className="space-y-2 text-sm text-green-700">
            <p>• <strong>Página de usuários</strong> carregada com sucesso</p>
            <p>• <strong>Navegação para equipe</strong> funcionando</p>
            <p>• <strong>Navegação para cargas horárias</strong> funcionando</p>
            <p>• <strong>Navegação para permissões</strong> funcionando</p>
          </div>
        </div>
      </div>
    </div>
  );
}
