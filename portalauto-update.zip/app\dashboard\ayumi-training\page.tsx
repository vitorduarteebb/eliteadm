import { redirect } from 'next/navigation';

export default function AyumiTrainingPage() {
  redirect('/dashboard/ayumi-training/overview');
}
