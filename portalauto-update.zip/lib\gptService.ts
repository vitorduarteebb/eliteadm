import { AYUMI_KNOWLEDGE, getCNHInfo, getInfracoesByGravidade, getDocumentacaoCNH, getRenovacaoInfo, getCassacaoInfo } from './ayumiKnowledge';

export interface GPTMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface GPTResponse {
  content: string;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

class GPTService {
  private apiKey: string;
  private baseURL: string = 'https://api.openai.com/v1/chat/completions';
  private model: string = 'gpt-4o-mini';

  constructor() {
    this.apiKey = process.env.OPENAI_API_KEY || '';
  }

  private async makeRequest(messages: GPTMessage[]): Promise<GPTResponse> {
    if (!this.apiKey) {
      throw new Error('API key do OpenAI não configurada');
    }

    try {
      const response = await fetch(this.baseURL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: this.model,
          messages,
          max_tokens: 1000,
          temperature: 0.7,
          stream: false,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Erro na API do GPT: ${errorData.error?.message || response.statusText}`);
      }

      const data = await response.json();
      
      return {
        content: data.choices[0]?.message?.content || 'Desculpe, não consegui gerar uma resposta.',
        usage: data.usage,
      };
    } catch (error) {
      console.error('Erro ao chamar API do GPT:', error);
      throw new Error('Erro ao processar sua pergunta. Tente novamente.');
    }
  }

  async getAutoEscolaResponse(userQuestion: string, contextDocuments: string[]): Promise<GPTResponse> {
    // Primeiro, tentar responder com conhecimento específico da Ayumi
    const specificAnswer = this.getSpecificAnswer(userQuestion);
    if (specificAnswer) {
      return {
        content: specificAnswer,
        usage: {
          prompt_tokens: 0,
          completion_tokens: specificAnswer.length,
          total_tokens: specificAnswer.length
        }
      };
    }

    // Se não encontrar resposta específica, usar GPT
    const systemPrompt = `Você é a Ayumi, uma IA especializada em Auto Escola Onishi. Sua função é responder perguntas relacionadas à autoescola, cursos de direção, legislação de trânsito e procedimentos da Auto Escola Onishi.

TEMAS QUE VOCÊ PODE RESPONDER:
✅ Autoescola e cursos de direção
✅ CNH (Carteira Nacional de Habilitação) - todos os tipos
✅ Legislação de trânsito brasileira
✅ Procedimentos da Auto Escola Onishi
✅ Documentação necessária para CNH
✅ Exames teóricos e práticos
✅ Infrações de trânsito e penalidades
✅ Primeira habilitação e renovação
✅ Mudança de categoria de CNH
✅ Cursos especializados (moto, carro, caminhão, etc.)
✅ Segurança no trânsito
✅ Direção defensiva
✅ Sinalização de trânsito
✅ Procedimentos administrativos do DETRAN

REGRAS IMPORTANTES:
1. Responda APENAS perguntas sobre os temas listados acima
2. Seja preciso, profissional e útil
3. Use as informações dos documentos fornecidos quando disponíveis
4. Responda em português brasileiro
5. Se não souber a resposta, diga que não tem a informação específica
6. Sempre ajude o usuário com informações relevantes sobre autoescola

CONTEXTO DOS DOCUMENTOS:
${contextDocuments.join('\n\n')}

Lembre-se: Você é especialista em autoescola e trânsito! Ajude sempre que possível.`;

    const messages: GPTMessage[] = [
      {
        role: 'system',
        content: systemPrompt
      },
      {
        role: 'user',
        content: userQuestion
      }
    ];

    return await this.makeRequest(messages);
  }

  private getSpecificAnswer(question: string): string | null {
    const questionLower = question.toLowerCase();
    
    // Verificar perguntas sobre CNH cassada
    if (questionLower.includes('cassada') || questionLower.includes('cassação') || questionLower.includes('cassar')) {
      return getCassacaoInfo();
    }
    
    // Verificar perguntas sobre documentação CNH
    if (questionLower.includes('documento') || questionLower.includes('documentação') || questionLower.includes('papel')) {
      if (questionLower.includes('categoria')) {
        const categoria = this.extractCategoria(question);
        if (categoria) return getDocumentacaoCNH(categoria);
      }
      return getDocumentacaoCNH('B'); // Categoria padrão
    }
    
    // Verificar perguntas sobre renovação
    if (questionLower.includes('renovar') || questionLower.includes('renovação') || questionLower.includes('vencida')) {
      if (questionLower.includes('categoria')) {
        const categoria = this.extractCategoria(question);
        if (categoria) return getRenovacaoInfo(categoria);
      }
      return getRenovacaoInfo('B'); // Categoria padrão
    }
    
    // Verificar perguntas sobre tipos de CNH
    if (questionLower.includes('categoria') || questionLower.includes('tipo')) {
      const categoria = this.extractCategoria(question);
      if (categoria) return getCNHInfo(categoria);
    }
    
    // Verificar perguntas sobre infrações
    if (questionLower.includes('infração') || questionLower.includes('multa') || questionLower.includes('penalidade')) {
      if (questionLower.includes('gravíssima') || questionLower.includes('gravissima')) {
        return getInfracoesByGravidade('gravissima');
      }
      if (questionLower.includes('grave')) {
        return getInfracoesByGravidade('grave');
      }
      if (questionLower.includes('média') || questionLower.includes('media')) {
        return getInfracoesByGravidade('media');
      }
      if (questionLower.includes('leve')) {
        return getInfracoesByGravidade('leve');
      }
    }
    
    // Verificar perguntas sobre exames
    if (questionLower.includes('exame') || questionLower.includes('prova')) {
      if (questionLower.includes('teórico') || questionLower.includes('teorico')) {
        return `Exame Teórico:\n\n${AYUMI_KNOWLEDGE.exames.teorico.descricao}\n\nAprovação: ${AYUMI_KNOWLEDGE.exames.teorico.aprovação}\nDuração: ${AYUMI_KNOWLEDGE.exames.teorico.duracao}\nCusto: ${AYUMI_KNOWLEDGE.exames.teorico.custo}`;
      }
      if (questionLower.includes('prático') || questionLower.includes('pratico')) {
        return `Exame Prático:\n\n${AYUMI_KNOWLEDGE.exames.pratico.descricao}\n\nDuração: ${AYUMI_KNOWLEDGE.exames.pratico.duracao}\nRequisitos: ${AYUMI_KNOWLEDGE.exames.pratico.requisitos}\nAvaliação: ${AYUMI_KNOWLEDGE.exames.pratico.avaliacao}`;
      }
    }
    
    // Verificar perguntas sobre Auto Escola Onishi
    if (questionLower.includes('onishi') || questionLower.includes('auto escola') || questionLower.includes('autoescola')) {
      return `Auto Escola Onishi:\n\n${AYUMI_KNOWLEDGE.autoEscolaOnishi.localizacao}\n\nServiços oferecidos:\n${AYUMI_KNOWLEDGE.autoEscolaOnishi.servicos.join('\n')}\n\nDiferencial:\n${AYUMI_KNOWLEDGE.autoEscolaOnishi.diferencial.join('\n')}`;
    }
    
    return null;
  }
  
  private extractCategoria(question: string): string | null {
    const questionLower = question.toLowerCase();
    const categorias = ['A', 'B', 'C', 'D', 'E'];
    
    for (const categoria of categorias) {
      if (questionLower.includes(categoria.toLowerCase())) {
        return categoria;
      }
    }
    
    return null;
  }

  async validateQuestion(question: string): Promise<boolean> {
    // Lista de palavras-chave relacionadas a autoescola e trânsito
    const autoEscolaKeywords = [
      'cnh', 'carteira', 'habilitação', 'licença', 'direção', 'condução',
      'autoescola', 'auto escola', 'escola de direção', 'curso de direção',
      'exame', 'prova', 'teórico', 'prático', 'detran', 'transito', 'trânsito',
      'legislação', 'lei', 'código', 'infração', 'multa', 'penalidade',
      'primeira habilitação', 'renovação', 'mudança categoria', 'adicionar categoria',
      'moto', 'carro', 'caminhão', 'ônibus', 'caminhonete', 'utilitário',
      'segurança', 'defensiva', 'sinalização', 'placa', 'sinal', 'semáforo',
      'documento', 'documentação', 'requisito', 'idade', 'escolaridade',
      'médico', 'psicólogo', 'oftalmologista', 'aptidão', 'apto', 'inapto',
      'cassada', 'suspensa', 'vencida', 'bloqueada', 'regularização',
      'auto escola onishi', 'onishi', 'eliteadm', 'sistema'
    ];

    // Converter pergunta para minúsculas para comparação
    const questionLower = question.toLowerCase();
    
    // Verificar se a pergunta contém palavras-chave relacionadas
    const hasAutoEscolaKeywords = autoEscolaKeywords.some(keyword => 
      questionLower.includes(keyword)
    );

    // Se não encontrou palavras-chave, usar validação GPT como fallback
    if (!hasAutoEscolaKeywords) {
      const validationPrompt = `Analise se a seguinte pergunta é sobre autoescola, cursos de direção, legislação de trânsito ou procedimentos de autoescola:

"${question}"

Responda apenas com "SIM" se for sobre autoescola/trânsito, ou "NÃO" se não for.`;

      try {
        const response = await this.makeRequest([
          {
            role: 'system',
            content: 'Você é um validador especializado em autoescola. Responda apenas com SIM ou NÃO.'
          },
          {
            role: 'user',
            content: validationPrompt
          }
        ]);

        return response.content.trim().toUpperCase().includes('SIM');
      } catch (error) {
        console.error('Erro na validação GPT:', error);
        // Em caso de erro, ser mais permissivo
        return true;
      }
    }

    return true;
  }
}

export const gptService = new GPTService();
