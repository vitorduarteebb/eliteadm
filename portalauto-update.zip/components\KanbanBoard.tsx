'use client';

import React, { useState, useCallback, useEffect } from 'react';
import {
  DndContext,
  DragEndEvent,
  DragOverEvent,
  DragOverlay,
  DragStartEvent,
  PointerSensor,
  useSensor,
  useSensors,
  closestCorners,
} from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
  arrayMove,
} from '@dnd-kit/sortable';
import { 
  Plus, 
  MoreVertical, 
  Calendar, 
  User, 
  Tag, 
  Clock,
  Edit3,
  Trash2,
  CheckCircle,
  AlertCircle,
  Clock as ClockIcon,
  RefreshCw,
  MessageSquare,
  Phone,
  Zap,
  Settings,
  X
} from 'lucide-react';
import { SortableTask } from './SortableTask';
import { TaskCard } from './TaskCard';

export interface KanbanTask {
  id: string;
  title: string;
  description: string;
  status: 'todo' | 'in-progress' | 'review' | 'done';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignee: string;
  dueDate: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  source?: string;
  leadId?: string;
  phone?: string;
  notes?: string;
}

export interface KanbanColumn {
  id: string;
  title: string;
  color: string;
  tasks: KanbanTask[];
}

const initialColumns: KanbanColumn[] = [
  {
    id: 'todo',
    title: 'A Fazer',
    color: 'bg-gray-100 border-gray-300',
    tasks: []
  },
  {
    id: 'in-progress',
    title: 'Em Andamento',
    color: 'bg-blue-100 border-blue-300',
    tasks: []
  },
  {
    id: 'review',
    title: 'Em Revisão',
    color: 'bg-yellow-100 border-yellow-300',
    tasks: []
  },
  {
    id: 'done',
    title: 'Concluído',
    color: 'bg-green-100 border-green-300',
    tasks: []
  }
];

const columnColors = [
  { name: 'Cinza', class: 'bg-gray-100 border-gray-300' },
  { name: 'Azul', class: 'bg-blue-100 border-blue-300' },
  { name: 'Verde', class: 'bg-green-100 border-green-300' },
  { name: 'Amarelo', class: 'bg-yellow-100 border-yellow-300' },
  { name: 'Roxo', class: 'bg-purple-100 border-purple-300' },
  { name: 'Rosa', class: 'bg-pink-100 border-pink-300' },
  { name: 'Laranja', class: 'bg-orange-100 border-orange-300' },
  { name: 'Vermelho', class: 'bg-red-100 border-red-300' }
];

const priorityColors = {
  low: 'bg-gray-200 text-gray-700',
  medium: 'bg-blue-200 text-blue-700',
  high: 'bg-orange-200 text-orange-700',
  urgent: 'bg-red-200 text-red-700'
};

const priorityIcons = {
  low: <ClockIcon className="h-3 w-3" />,
  medium: <AlertCircle className="h-3 w-3" />,
  high: <AlertCircle className="h-3 w-3" />,
  urgent: <AlertCircle className="h-3 w-3" />
};

export function KanbanBoard() {
  const [columns, setColumns] = useState<KanbanColumn[]>(initialColumns);
  const [showAddTask, setShowAddTask] = useState(false);
  const [editingTask, setEditingTask] = useState<KanbanTask | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAssignee, setFilterAssignee] = useState('');
  const [filterPriority, setFilterPriority] = useState<string>('');
  const [filterSource, setFilterSource] = useState<string>('');
  const [activeTask, setActiveTask] = useState<KanbanTask | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string>('');
  
  // Estados para edição de colunas
  const [editingColumn, setEditingColumn] = useState<string | null>(null);
  const [showAddColumn, setShowAddColumn] = useState(false);
  const [newColumnTitle, setNewColumnTitle] = useState('');
  const [newColumnColor, setNewColumnColor] = useState(columnColors[0].class);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  // Carregar dados do localStorage
  useEffect(() => {
    const savedColumns = localStorage.getItem('kanban-columns');
    if (savedColumns) {
      try {
        setColumns(JSON.parse(savedColumns));
      } catch (error) {
        console.error('Erro ao carregar dados do Kanban:', error);
      }
    }
  }, []);

  // Salvar dados no localStorage
  useEffect(() => {
    localStorage.setItem('kanban-columns', JSON.stringify(columns));
  }, [columns]);

  // Sincronizar com Bradial
  const syncWithBradial = useCallback(async () => {
    setIsSyncing(true);
    setSyncStatus('Sincronizando com Bradial...');
    
    try {
      const response = await fetch('/api/bradial-sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'sync' }),
      });

      const data = await response.json();
      
      if (data.success) {
        // Adicionar leads do Bradial ao Kanban
        const bradialLeads = data.leads || [];
        const newColumns = [...columns];
        
        bradialLeads.forEach((lead: any) => {
          // Verificar se o lead já existe
          const existingTask = newColumns
            .flatMap(col => col.tasks)
            .find(task => task.leadId === lead.leadId);
          
          if (!existingTask) {
            // Adicionar novo lead na coluna apropriada
            const targetColumn = newColumns.find(col => col.id === lead.status);
            if (targetColumn) {
              targetColumn.tasks.push(lead);
            }
          }
        });
        
        setColumns(newColumns);
        setSyncStatus(`Sincronização concluída! ${data.count} leads importados.`);
        
        // Limpar status após 3 segundos
        setTimeout(() => setSyncStatus(''), 3000);
      } else {
        setSyncStatus('Erro na sincronização: ' + data.message);
      }
    } catch (error) {
      console.error('Erro ao sincronizar com Bradial:', error);
      setSyncStatus('Erro na sincronização. Tente novamente.');
    } finally {
      setIsSyncing(false);
    }
  }, [columns]);

  // Funções para gerenciar colunas
  const addColumn = () => {
    if (newColumnTitle.trim()) {
      const newColumn: KanbanColumn = {
        id: `column-${Date.now()}`,
        title: newColumnTitle.trim(),
        color: newColumnColor,
        tasks: []
      };
      
      setColumns(prev => [...prev, newColumn]);
      setNewColumnTitle('');
      setNewColumnColor(columnColors[0].class);
      setShowAddColumn(false);
    }
  };

  const updateColumnTitle = (columnId: string, newTitle: string) => {
    if (newTitle.trim()) {
      setColumns(prev => prev.map(col => 
        col.id === columnId 
          ? { ...col, title: newTitle.trim() }
          : col
      ));
      setEditingColumn(null);
    }
  };

  const updateColumnColor = (columnId: string, newColor: string) => {
    setColumns(prev => prev.map(col => 
      col.id === columnId 
        ? { ...col, color: newColor }
        : col
    ));
  };

  const deleteColumn = (columnId: string) => {
    const column = columns.find(col => col.id === columnId);
    if (column && column.tasks.length > 0) {
      if (!confirm(`A coluna "${column.title}" tem ${column.tasks.length} tarefas. Deseja realmente excluí-la?`)) {
        return;
      }
    }
    
    setColumns(prev => prev.filter(col => col.id !== columnId));
  };

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const task = findTask(active.id as string);
    setActiveTask(task);
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    
    if (!over) return;

    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) return;

    const activeContainer = findContainer(activeId);
    const overContainer = findContainer(overId);

    if (
      !activeContainer ||
      !overContainer ||
      activeContainer === overContainer
    ) {
      return;
    }

    setColumns(prev => {
      const activeItems = prev.find(col => col.id === activeContainer)?.tasks || [];
      const overItems = prev.find(col => col.id === overContainer)?.tasks || [];
      
      const activeIndex = activeItems.findIndex(item => item.id === activeId);
      const overIndex = overItems.findIndex(item => item.id === overId);

      let newIndex: number;
      
      if (overId in prev) {
        newIndex = overItems.length + 1;
      } else {
        const isBelowOverItem =
          over &&
          active.rect.current.translated &&
          active.rect.current.translated.top > over.rect.top + over.rect.height;

        const modifier = isBelowOverItem ? 1 : 0;
        newIndex = overIndex >= 0 ? overIndex + modifier : overItems.length + 1;
      }

      const newColumns = prev.map(col => {
        if (col.id === activeContainer) {
          return {
            ...col,
            tasks: col.tasks.filter(item => item.id !== activeId)
          };
        }
        if (col.id === overContainer) {
          return {
            ...col,
            tasks: [
              ...col.tasks.slice(0, newIndex),
              activeItems[activeIndex],
              ...col.tasks.slice(newIndex, col.tasks.length)
            ]
          };
        }
        return col;
      });

      return newColumns;
    });
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (!over) {
      setActiveTask(null);
      return;
    }

    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) {
      setActiveTask(null);
      return;
    }

    const activeContainer = findContainer(activeId);
    const overContainer = findContainer(overId);

    if (
      !activeContainer ||
      !overContainer ||
      activeContainer !== overContainer
    ) {
      setActiveTask(null);
      return;
    }

    setColumns(prev => {
      const activeItems = prev.find(col => col.id === activeContainer)?.tasks || [];
      const activeIndex = activeItems.findIndex(item => item.id === activeId);
      const overIndex = activeItems.findIndex(item => item.id === overId);

      if (activeIndex !== -1 && overIndex !== -1) {
        const newColumns = prev.map(col => {
          if (col.id === activeContainer) {
            return {
              ...col,
              tasks: arrayMove(col.tasks, activeIndex, overIndex)
            };
          }
          return col;
        });
        return newColumns;
      }

      return prev;
    });

    setActiveTask(null);
  };

  const findTask = (id: string | number): KanbanTask | null => {
    for (const column of columns) {
      const task = column.tasks.find(task => task.id === id);
      if (task) return task;
    }
    return null;
  };

  const findContainer = (id: string | number): string => {
    if (id in columns) {
      return id as string;
    }

    for (const column of columns) {
      if (column.tasks.find(task => task.id === id)) {
        return column.id;
      }
    }

    return 'todo';
  };

  const addTask = (taskData: Omit<KanbanTask, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newTask: KanbanTask = {
      ...taskData,
      id: `task-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const newColumns = columns.map(col => {
      if (col.id === 'todo') {
        return { ...col, tasks: [...col.tasks, newTask] };
      }
      return col;
    });

    setColumns(newColumns);
    setShowAddTask(false);
  };

  const updateTask = (taskId: string, updates: Partial<KanbanTask>) => {
    const newColumns = columns.map(col => ({
      ...col,
      tasks: col.tasks.map(task => 
        task.id === taskId 
          ? { ...task, ...updates, updatedAt: new Date().toISOString() }
          : task
      )
    }));

    setColumns(newColumns);
    setEditingTask(null);
  };

  const deleteTask = (taskId: string) => {
    const newColumns = columns.map(col => ({
      ...col,
      tasks: col.tasks.filter(task => task.id !== taskId)
    }));

    setColumns(newColumns);
  };

  const filteredColumns = columns.map(col => ({
    ...col,
    tasks: col.tasks.filter(task => {
      const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           task.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesAssignee = !filterAssignee || task.assignee === filterAssignee;
      const matchesPriority = !filterPriority || task.priority === filterPriority;
      const matchesSource = !filterSource || task.source === filterSource;
      
      return matchesSearch && matchesAssignee && matchesPriority && matchesSource;
    })
  }));

  const allAssignees = Array.from(new Set(
    columns.flatMap(col => col.tasks.map(task => task.assignee))
  )).filter(Boolean);

  const allSources = Array.from(new Set(
    columns.flatMap(col => col.tasks.map(task => task.source))
  )).filter(Boolean);

  const bradialTasksCount = columns
    .flatMap(col => col.tasks)
    .filter(task => task.source === 'Bradial').length;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Quadro Kanban</h1>
              <p className="text-gray-600">Gerencie suas tarefas e projetos de forma visual</p>
            </div>
            
            {/* Botão de Sincronização Bradial */}
            <div className="flex items-center gap-4">
              {syncStatus && (
                <div className={`px-4 py-2 rounded-lg text-sm ${
                  syncStatus.includes('Erro') 
                    ? 'bg-red-100 text-red-700' 
                    : 'bg-green-100 text-green-700'
                }`}>
                  {syncStatus}
                </div>
              )}
              
              <button
                onClick={syncWithBradial}
                disabled={isSyncing}
                className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <RefreshCw className={`h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`} />
                {isSyncing ? 'Sincronizando...' : 'Sincronizar Bradial'}
              </button>
            </div>
          </div>
          
          {/* Estatísticas Bradial */}
          {bradialTasksCount > 0 && (
            <div className="mt-4 bg-purple-50 border border-purple-200 rounded-lg p-4">
              <div className="flex items-center gap-2 text-purple-700">
                <MessageSquare className="h-5 w-5" />
                <span className="font-medium">Integração Bradial Ativa</span>
              </div>
              <p className="text-purple-600 text-sm mt-1">
                {bradialTasksCount} leads do WhatsApp sincronizados automaticamente
              </p>
            </div>
          )}
        </div>

        {/* Filtros e Controles */}
        <div className="mb-6 flex flex-wrap gap-4 items-center justify-between bg-white p-4 rounded-lg shadow-sm">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="relative">
              <input
                type="text"
                placeholder="Buscar tarefas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <div className="absolute left-3 top-2.5 text-gray-400">
                <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>

            <select
              value={filterAssignee}
              onChange={(e) => setFilterAssignee(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Todos os responsáveis</option>
              {allAssignees.map(assignee => (
                <option key={assignee} value={assignee}>{assignee}</option>
              ))}
            </select>

            <select
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Todas as prioridades</option>
              <option value="low">Baixa</option>
              <option value="medium">Média</option>
              <option value="high">Alta</option>
              <option value="urgent">Urgente</option>
            </select>

            <select
              value={filterSource}
              onChange={(e) => setFilterSource(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Todas as fontes</option>
              <option value="Bradial">Bradial (WhatsApp)</option>
              <option value="Manual">Manual</option>
            </select>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setShowAddColumn(true)}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Nova Coluna
            </button>
            
            <button
              onClick={() => setShowAddTask(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Nova Tarefa
            </button>
          </div>
        </div>

        {/* Quadro Kanban */}
        <DndContext
          sensors={sensors}
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
        >
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {filteredColumns.map((column) => (
              <div key={column.id} className="flex flex-col">
                <div className={`p-4 rounded-t-lg border ${column.color}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 flex-1">
                      {editingColumn === column.id ? (
                        <input
                          type="text"
                          value={column.title}
                          onChange={(e) => {
                            const newColumns = columns.map(col => 
                              col.id === column.id 
                                ? { ...col, title: e.target.value }
                                : col
                            );
                            setColumns(newColumns);
                          }}
                          onBlur={() => updateColumnTitle(column.id, column.title)}
                          onKeyPress={(e) => e.key === 'Enter' && updateColumnTitle(column.id, column.title)}
                          className="font-semibold text-gray-800 bg-white px-2 py-1 rounded border focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          autoFocus
                        />
                      ) : (
                        <h3 
                          className="font-semibold text-gray-800 cursor-pointer hover:bg-white hover:bg-opacity-50 px-2 py-1 rounded"
                          onClick={() => setEditingColumn(column.id)}
                        >
                          {column.title}
                        </h3>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="bg-white bg-opacity-50 px-2 py-1 rounded-full text-sm font-medium">
                        {column.tasks.length}
                      </span>
                      
                      <div className="relative group">
                        <button className="text-gray-600 hover:text-gray-800 p-1">
                          <Settings className="h-4 w-4" />
                        </button>
                        
                        {/* Menu de configurações da coluna */}
                        <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg p-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity min-w-48">
                          <div className="space-y-2">
                            <button
                              onClick={() => setEditingColumn(column.id)}
                              className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded flex items-center gap-2"
                            >
                              <Edit3 className="h-4 w-4" />
                              Editar título
                            </button>
                            
                            <div className="px-3 py-2">
                              <label className="block text-xs font-medium text-gray-700 mb-1">
                                Cor da coluna
                              </label>
                              <div className="grid grid-cols-4 gap-1">
                                {columnColors.map((color) => (
                                  <button
                                    key={color.class}
                                    onClick={() => updateColumnColor(column.id, color.class)}
                                    className={`w-6 h-6 rounded border-2 ${
                                      column.color === color.class 
                                        ? 'border-gray-800' 
                                        : 'border-gray-300'
                                    } ${color.class}`}
                                    title={color.name}
                                  />
                                ))}
                              </div>
                            </div>
                            
                            {columns.length > 1 && (
                              <button
                                onClick={() => deleteColumn(column.id)}
                                className="w-full text-left px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded flex items-center gap-2"
                              >
                                <Trash2 className="h-4 w-4" />
                                Excluir coluna
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="min-h-[500px] p-2 bg-white border-l border-r border-b rounded-b-lg">
                  <SortableContext
                    items={column.tasks.map(task => task.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    {column.tasks.map((task) => (
                      <SortableTask
                        key={task.id}
                        task={task}
                        onEdit={() => setEditingTask(task)}
                        onDelete={() => deleteTask(task.id)}
                        priorityColors={priorityColors}
                        priorityIcons={priorityIcons}
                      />
                    ))}
                  </SortableContext>
                </div>
              </div>
            ))}
          </div>

          <DragOverlay>
            {activeTask ? (
              <TaskCard
                task={activeTask}
                priorityColors={priorityColors}
                priorityIcons={priorityIcons}
                isDragging={true}
              />
            ) : null}
          </DragOverlay>
        </DndContext>
      </div>

      {/* Modal Adicionar Coluna */}
      {showAddColumn && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Nova Coluna</h2>
              <button
                onClick={() => setShowAddColumn(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Título da Coluna *
                </label>
                <input
                  type="text"
                  required
                  value={newColumnTitle}
                  onChange={(e) => setNewColumnTitle(e.target.value)}
                  placeholder="Ex: Em Análise, Aguardando Aprovação..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Cor da Coluna
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {columnColors.map((color) => (
                    <button
                      key={color.class}
                      onClick={() => setNewColumnColor(color.class)}
                      className={`w-12 h-12 rounded border-2 ${
                        newColumnColor === color.class 
                          ? 'border-gray-800' 
                          : 'border-gray-300'
                      } ${color.class}`}
                      title={color.name}
                    />
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={addColumn}
                  disabled={!newColumnTitle.trim()}
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Criar Coluna
                </button>
                <button
                  onClick={() => setShowAddColumn(false)}
                  className="flex-1 bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Adicionar Tarefa */}
      {showAddTask && (
        <TaskModal
          onClose={() => setShowAddTask(false)}
          onSubmit={addTask}
          mode="add"
        />
      )}

      {/* Modal Editar Tarefa */}
      {editingTask && (
        <TaskModal
          onClose={() => setEditingTask(null)}
          onSubmit={(taskData) => updateTask(editingTask.id, taskData)}
          mode="edit"
          task={editingTask}
        />
      )}
    </div>
  );
}

interface TaskModalProps {
  onClose: () => void;
  onSubmit: (taskData: Omit<KanbanTask, 'id' | 'createdAt' | 'updatedAt'>) => void;
  mode: 'add' | 'edit';
  task?: KanbanTask;
}

function TaskModal({ onClose, onSubmit, mode, task }: TaskModalProps) {
  const [formData, setFormData] = useState({
    title: task?.title || '',
    description: task?.description || '',
    status: task?.status || 'todo',
    priority: task?.priority || 'medium',
    assignee: task?.assignee || '',
    dueDate: task?.dueDate || new Date().toISOString().split('T')[0],
    tags: task?.tags || []
  });

  const [newTag, setNewTag] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <h2 className="text-xl font-semibold mb-4">
          {mode === 'add' ? 'Nova Tarefa' : 'Editar Tarefa'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Título *
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Descrição
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as any }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="todo">A Fazer</option>
                <option value="in-progress">Em Andamento</option>
                <option value="review">Em Revisão</option>
                <option value="done">Concluído</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Prioridade
              </label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData(prev => ({ ...prev, priority: e.target.value as any }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="low">Baixa</option>
                <option value="medium">Média</option>
                <option value="high">Alta</option>
                <option value="urgent">Urgente</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Responsável
              </label>
              <input
                type="text"
                value={formData.assignee}
                onChange={(e) => setFormData(prev => ({ ...prev, assignee: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data de Vencimento
              </label>
              <input
                type="date"
                value={formData.dueDate}
                onChange={(e) => setFormData(prev => ({ ...prev, dueDate: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tags
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                placeholder="Adicionar tag..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                type="button"
                onClick={addTag}
                className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.tags.map((tag, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-blue-100 text-blue-700 text-sm rounded-full flex items-center gap-1"
                >
                  {tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="text-blue-500 hover:text-blue-700"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
            >
              {mode === 'add' ? 'Criar Tarefa' : 'Salvar Alterações'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300"
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
