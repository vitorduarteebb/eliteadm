'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { 
  Clock, 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  Calendar,
  ArrowLeft,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  User,
  BarChart3
} from 'lucide-react';

interface WorkloadEntry {
  id: string;
  userId: string;
  userName: string;
  date: Date;
  hoursWorked: number;
  hoursScheduled: number;
  project: string;
  task: string;
  status: 'completed' | 'in-progress' | 'overdue' | 'planned';
  notes?: string;
}

export default function CargasHorariasPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'in-progress' | 'overdue' | 'planned'>('all');
  const [dateFilter, setDateFilter] = useState('all');

  // Dados mockados para demonstração
  const [workloadEntries] = useState<WorkloadEntry[]>([
    {
      id: '1',
      userId: '1',
      userName: 'João Silva',
      date: new Date('2024-01-15'),
      hoursWorked: 8,
      hoursScheduled: 8,
      project: 'EliteADM',
      task: 'Desenvolvimento Frontend',
      status: 'completed',
      notes: 'Tarefa concluída com sucesso'
    },
    {
      id: '2',
      userId: '2',
      userName: 'Maria Santos',
      date: new Date('2024-01-15'),
      hoursWorked: 6,
      hoursScheduled: 8,
      project: 'EliteADM',
      task: 'Análise de Requisitos',
      status: 'in-progress',
      notes: 'Em análise dos requisitos do sistema'
    },
    {
      id: '3',
      userId: '3',
      userName: 'Pedro Costa',
      date: new Date('2024-01-15'),
      hoursWorked: 10,
      hoursScheduled: 8,
      project: 'EliteADM',
      task: 'Design de Interface',
      status: 'overdue',
      notes: 'Horas extras para finalizar o design'
    },
    {
      id: '4',
      userId: '4',
      userName: 'Ana Oliveira',
      date: new Date('2024-01-16'),
      hoursWorked: 0,
      hoursScheduled: 8,
      project: 'EliteADM',
      task: 'Reunião de Planejamento',
      status: 'planned',
      notes: 'Reunião agendada para amanhã'
    },
    {
      id: '5',
      userId: '1',
      userName: 'João Silva',
      date: new Date('2024-01-16'),
      hoursWorked: 0,
      hoursScheduled: 8,
      project: 'EliteADM',
      task: 'Testes de Integração',
      status: 'planned',
      notes: 'Testes programados para amanhã'
    }
  ]);

  const filteredEntries = workloadEntries.filter(entry => {
    const matchesSearch = entry.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.project.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.task.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || entry.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      case 'planned': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'in-progress': return <TrendingUp className="h-4 w-4" />;
      case 'overdue': return <AlertTriangle className="h-4 w-4" />;
      case 'planned': return <Calendar className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Concluído';
      case 'in-progress': return 'Em Progresso';
      case 'overdue': return 'Atrasado';
      case 'planned': return 'Planejado';
      default: return 'Desconhecido';
    }
  };

  const totalHoursWorked = workloadEntries.reduce((acc, entry) => acc + entry.hoursWorked, 0);
  const totalHoursScheduled = workloadEntries.reduce((acc, entry) => acc + entry.hoursScheduled, 0);
  const efficiency = totalHoursScheduled > 0 ? (totalHoursWorked / totalHoursScheduled) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-lg border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => router.push('/users')}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
                <span>Voltar</span>
              </button>
              <div className="h-6 w-px bg-gray-300"></div>
              <h1 className="text-2xl font-bold text-gray-900">Gestão de Cargas Horárias</h1>
            </div>
            <button
              onClick={() => router.push('/dashboard')}
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Dashboard
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total de Horas Trabalhadas</p>
                <p className="text-2xl font-bold text-blue-600">{totalHoursWorked}h</p>
              </div>
              <div className="p-3 rounded-full bg-blue-100">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Horas Programadas</p>
                <p className="text-2xl font-bold text-green-600">{totalHoursScheduled}h</p>
              </div>
              <div className="p-3 rounded-full bg-green-100">
                <Calendar className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Eficiência</p>
                <p className="text-2xl font-bold text-purple-600">{efficiency.toFixed(1)}%</p>
              </div>
              <div className="p-3 rounded-full bg-purple-100">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Tarefas Ativas</p>
                <p className="text-2xl font-bold text-orange-600">
                  {workloadEntries.filter(e => e.status === 'in-progress').length}
                </p>
              </div>
              <div className="p-3 rounded-full bg-orange-100">
                <BarChart3 className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <input
                  type="text"
                  placeholder="Buscar por usuário, projeto ou tarefa..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Todos os Status</option>
              <option value="completed">Concluído</option>
              <option value="in-progress">Em Progresso</option>
              <option value="overdue">Atrasado</option>
              <option value="planned">Planejado</option>
            </select>

            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>Nova Entrada</span>
            </button>
          </div>
        </div>

        {/* Workload Entries Table */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Registros de Carga Horária</h3>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Usuário
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Data
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Projeto
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Tarefa
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Horas
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredEntries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                            <User className="h-5 w-5 text-blue-600" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{entry.userName}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {entry.date.toLocaleDateString('pt-BR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {entry.project}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {entry.task}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium">{entry.hoursWorked}h</span>
                          <span className="text-gray-400">/</span>
                          <span className="text-gray-500">{entry.hoursScheduled}h</span>
                        </div>
                        {entry.hoursWorked > entry.hoursScheduled && (
                          <div className="text-xs text-red-600 mt-1">
                            +{(entry.hoursWorked - entry.hoursScheduled)}h extras
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(entry.status)}`}>
                        {getStatusIcon(entry.status)}
                        <span className="ml-1">{getStatusText(entry.status)}</span>
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <button className="text-blue-600 hover:text-blue-900">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="text-red-600 hover:text-red-900">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Summary */}
        <div className="bg-white rounded-lg shadow-lg p-6 mt-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Resumo da Carga Horária</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{totalHoursWorked}h</div>
              <div className="text-sm text-gray-600">Total Trabalhado</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{totalHoursScheduled}h</div>
              <div className="text-sm text-gray-600">Total Programado</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{efficiency.toFixed(1)}%</div>
              <div className="text-sm text-gray-600">Taxa de Eficiência</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
