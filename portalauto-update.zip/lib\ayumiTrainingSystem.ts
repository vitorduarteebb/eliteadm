// Sistema Real de Treinamento da IA Ayumi
export interface TrainingFeedback {
  id: string;
  question: string;
  originalAnswer: string;
  userFeedback: 'positive' | 'negative' | 'neutral';
  feedbackText: string;
  correctedAnswer?: string;
  category: string;
  timestamp: Date;
  status: 'pending' | 'reviewed' | 'implemented' | 'rejected';
  priority: 'low' | 'medium' | 'high' | 'critical';
  confidence: number; // 0-1
  userRating: number; // 1-5
  tags: string[];
  metadata: {
    userAgent: string;
    sessionId: string;
    responseTime: number;
    context?: string;
  };
}

export interface TrainingMetrics {
  totalInteractions: number;
  accuracy: number;
  userSatisfaction: number;
  responseTime: number;
  feedbackCount: number;
  improvementRate: number;
  categoryPerformance: {
    name: string;
    accuracy: number;
    usage: number;
    satisfaction: number;
    feedbackCount: number;
  }[];
}

export interface KnowledgeBaseEntry {
  id: string;
  question: string;
  answer: string;
  category: string;
  confidence: number;
  lastUpdated: Date;
  version: number;
  sources: string[];
  tags: string[];
  usageCount: number;
  accuracyScore: number;
}

class AyumiTrainingSystem {
  private feedback: TrainingFeedback[] = [];
  private knowledgeBase: KnowledgeBaseEntry[] = [];
  private metrics: TrainingMetrics;

  constructor() {
    this.loadData();
    this.initializeMetrics();
  }

  // Carregar dados salvos
  private loadData() {
    try {
      if (typeof window !== 'undefined') {
        const savedFeedback = localStorage.getItem('ayumi-feedback');
        const savedKnowledge = localStorage.getItem('ayumi-knowledge');
        
        if (savedFeedback) {
          this.feedback = JSON.parse(savedFeedback).map((f: any) => ({
            ...f,
            timestamp: new Date(f.timestamp)
          }));
        }
        
        if (savedKnowledge) {
          this.knowledgeBase = JSON.parse(savedKnowledge).map((k: any) => ({
            ...k,
            lastUpdated: new Date(k.lastUpdated)
          }));
        }
      }
    } catch (error) {
      console.error('Erro ao carregar dados de treinamento:', error);
    }
  }

  // Salvar dados
  private saveData() {
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem('ayumi-feedback', JSON.stringify(this.feedback));
        localStorage.setItem('ayumi-knowledge', JSON.stringify(this.knowledgeBase));
      }
    } catch (error) {
      console.error('Erro ao salvar dados de treinamento:', error);
    }
  }

  // Inicializar métricas
  private initializeMetrics() {
    this.metrics = {
      totalInteractions: 0,
      accuracy: 0.85,
      userSatisfaction: 0.80,
      responseTime: 1.2,
      feedbackCount: this.feedback.length,
      improvementRate: 0.05,
      categoryPerformance: []
    };
    this.updateMetrics();
  }

  // Adicionar feedback de treinamento
  addFeedback(feedback: Omit<TrainingFeedback, 'id' | 'timestamp'>): string {
    const id = `feedback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const newFeedback: TrainingFeedback = {
      ...feedback,
      id,
      timestamp: new Date()
    };

    this.feedback.push(newFeedback);
    this.saveData();
    this.updateMetrics();
    
    // Aplicar aprendizado automático se feedback for negativo
    if (feedback.userFeedback === 'negative' && feedback.correctedAnswer) {
      this.learnFromFeedback(newFeedback);
    }

    return id;
  }

  // Aprender com feedback
  private learnFromFeedback(feedback: TrainingFeedback) {
    if (!feedback.correctedAnswer) return;

    // Atualizar base de conhecimento
    const existingEntry = this.knowledgeBase.find(
      entry => entry.question.toLowerCase() === feedback.question.toLowerCase()
    );

    if (existingEntry) {
      // Atualizar entrada existente
      existingEntry.answer = feedback.correctedAnswer;
      existingEntry.lastUpdated = new Date();
      existingEntry.version += 1;
      existingEntry.accuracyScore = Math.min(existingEntry.accuracyScore + 0.1, 1.0);
    } else {
      // Criar nova entrada
      const newEntry: KnowledgeBaseEntry = {
        id: `kb_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        question: feedback.question,
        answer: feedback.correctedAnswer,
        category: feedback.category,
        confidence: 0.8,
        lastUpdated: new Date(),
        version: 1,
        sources: ['user-feedback'],
        tags: feedback.tags,
        usageCount: 1,
        accuracyScore: 0.8
      };
      this.knowledgeBase.push(newEntry);
    }

    this.saveData();
    this.updateMetrics();
  }

  // Treinar IA com conjunto de dados
  trainWithDataset(dataset: Array<{question: string, answer: string, category: string}>) {
    console.log('🧠 Iniciando treinamento da IA com dataset...');
    
    let trainedCount = 0;
    let updatedCount = 0;

    dataset.forEach(item => {
      const existingEntry = this.knowledgeBase.find(
        entry => entry.question.toLowerCase() === item.question.toLowerCase()
      );

      if (existingEntry) {
        // Atualizar entrada existente
        existingEntry.answer = item.answer;
        existingEntry.lastUpdated = new Date();
        existingEntry.version += 1;
        existingEntry.accuracyScore = Math.min(existingEntry.accuracyScore + 0.05, 1.0);
        updatedCount++;
      } else {
        // Criar nova entrada
        const newEntry: KnowledgeBaseEntry = {
          id: `kb_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          question: item.question,
          answer: item.answer,
          category: item.category,
          confidence: 0.9,
          lastUpdated: new Date(),
          version: 1,
          sources: ['training-dataset'],
          tags: [item.category.toLowerCase()],
          usageCount: 0,
          accuracyScore: 0.9
        };
        this.knowledgeBase.push(newEntry);
        trainedCount++;
      }
    });

    this.saveData();
    this.updateMetrics();

    console.log(`✅ Treinamento concluído: ${trainedCount} novas entradas, ${updatedCount} atualizadas`);
    
    return {
      trainedCount,
      updatedCount,
      totalEntries: this.knowledgeBase.length
    };
  }

  // Aplicar melhorias baseadas em feedback
  applyImprovements(): {applied: number, total: number} {
    console.log('🔧 Aplicando melhorias baseadas em feedback...');
    
    const pendingFeedback = this.feedback.filter(f => f.status === 'pending');
    let appliedCount = 0;

    pendingFeedback.forEach(feedback => {
      if (feedback.correctedAnswer && feedback.userFeedback === 'negative') {
        this.learnFromFeedback(feedback);
        feedback.status = 'implemented';
        appliedCount++;
      }
    });

    this.saveData();
    this.updateMetrics();

    console.log(`✅ Melhorias aplicadas: ${appliedCount}/${pendingFeedback.length}`);
    
    return {
      applied: appliedCount,
      total: pendingFeedback.length
    };
  }

  // Atualizar métricas
  private updateMetrics() {
    if (this.feedback.length === 0) return;

    const positiveFeedback = this.feedback.filter(f => f.userFeedback === 'positive').length;
    const totalFeedback = this.feedback.length;
    
    this.metrics.feedbackCount = totalFeedback;
    this.metrics.userSatisfaction = positiveFeedback / totalFeedback;
    
    // Calcular performance por categoria
    const categoryStats = new Map<string, {accuracy: number, usage: number, satisfaction: number, feedbackCount: number}>();
    
    this.feedback.forEach(f => {
      if (!categoryStats.has(f.category)) {
        categoryStats.set(f.category, {accuracy: 0, usage: 0, satisfaction: 0, feedbackCount: 0});
      }
      
      const stats = categoryStats.get(f.category)!;
      stats.feedbackCount++;
      stats.satisfaction += f.userFeedback === 'positive' ? 1 : 0;
      stats.accuracy += f.confidence;
      stats.usage += 1;
    });

    this.metrics.categoryPerformance = Array.from(categoryStats.entries()).map(([name, stats]) => ({
      name,
      accuracy: stats.accuracy / stats.usage,
      usage: stats.usage,
      satisfaction: stats.satisfaction / stats.feedbackCount,
      feedbackCount: stats.feedbackCount
    }));

    // Calcular taxa de melhoria
    const recentFeedback = this.feedback.filter(f => {
      const daysAgo = (Date.now() - f.timestamp.getTime()) / (1000 * 60 * 60 * 24);
      return daysAgo <= 30;
    });

    if (recentFeedback.length > 0) {
      const recentSatisfaction = recentFeedback.filter(f => f.userFeedback === 'positive').length / recentFeedback.length;
      this.metrics.improvementRate = recentSatisfaction - this.metrics.userSatisfaction;
    }
  }

  // Obter métricas
  getMetrics(): TrainingMetrics {
    return { ...this.metrics };
  }

  // Obter feedback
  getFeedback(status?: string): TrainingFeedback[] {
    if (status) {
      return this.feedback.filter(f => f.status === status);
    }
    return [...this.feedback].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  // Obter base de conhecimento
  getKnowledgeBase(): KnowledgeBaseEntry[] {
    return [...this.knowledgeBase];
  }

  // Buscar na base de conhecimento
  searchKnowledge(query: string): KnowledgeBaseEntry[] {
    const queryLower = query.toLowerCase();
    return this.knowledgeBase.filter(entry => 
      entry.question.toLowerCase().includes(queryLower) ||
      entry.answer.toLowerCase().includes(queryLower) ||
      entry.tags.some(tag => tag.toLowerCase().includes(queryLower))
    );
  }

  // Exportar dados de treinamento
  exportTrainingData(): string {
    const data = {
      feedback: this.feedback,
      knowledgeBase: this.knowledgeBase,
      metrics: this.metrics,
      exportDate: new Date().toISOString()
    };
    return JSON.stringify(data, null, 2);
  }

  // Importar dados de treinamento
  importTrainingData(jsonData: string): {success: boolean, message: string} {
    try {
      const data = JSON.parse(jsonData);
      
      if (data.feedback && Array.isArray(data.feedback)) {
        this.feedback = data.feedback.map((f: any) => ({
          ...f,
          timestamp: new Date(f.timestamp)
        }));
      }
      
      if (data.knowledgeBase && Array.isArray(data.knowledgeBase)) {
        this.knowledgeBase = data.knowledgeBase.map((k: any) => ({
          ...k,
          lastUpdated: new Date(k.lastUpdated)
        }));
      }
      
      this.saveData();
      this.updateMetrics();
      
      return { success: true, message: 'Dados importados com sucesso!' };
    } catch (error) {
      return { success: false, message: `Erro ao importar dados: ${error}` };
    }
  }

  // Limpar dados antigos
  cleanupOldData(daysToKeep: number = 90): {cleaned: number, total: number} {
    const cutoffDate = new Date(Date.now() - daysToKeep * 24 * 60 * 60 * 1000);
    const oldFeedback = this.feedback.filter(f => f.timestamp < cutoffDate);
    
    this.feedback = this.feedback.filter(f => f.timestamp >= cutoffDate);
    this.saveData();
    this.updateMetrics();
    
    return {
      cleaned: oldFeedback.length,
      total: this.feedback.length
    };
  }
}

// Instância global do sistema de treinamento
export const ayumiTrainingSystem = new AyumiTrainingSystem();

// Funções utilitárias para uso externo
export const addTrainingFeedback = (feedback: Omit<TrainingFeedback, 'id' | 'timestamp'>) => {
  return ayumiTrainingSystem.addFeedback(feedback);
};

export const trainAyumiWithDataset = (dataset: Array<{question: string, answer: string, category: string}>) => {
  return ayumiTrainingSystem.trainWithDataset(dataset);
};

export const applyAyumiImprovements = () => {
  return ayumiTrainingSystem.applyImprovements();
};

export const getAyumiMetrics = () => {
  return ayumiTrainingSystem.getMetrics();
};

export const getAyumiFeedback = (status?: string) => {
  return ayumiTrainingSystem.getFeedback(status);
};

export const searchAyumiKnowledge = (query: string) => {
  return ayumiTrainingSystem.searchKnowledge(query);
};
